--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.3
-- Dumped by pg_dump version 12.4 (Ubuntu 12.4-1.pgdg18.04+1)

-- Started on 2020-09-03 18:43:05 CEST

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


ALTER SCHEMA public OWNER TO microaccounts_dev;

--
-- TOC entry 6 (class 2615 OID 195849)
-- Name: addons; Type: SCHEMA; Schema: -; Owner: psql_root
--

CREATE SCHEMA addons;



--
-- TOC entry 2 (class 3079 OID 195850)
-- Name: hstore; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS hstore WITH SCHEMA addons;


--
-- TOC entry 2502 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION hstore; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION hstore IS 'data type for storing sets of (key, value) pairs';


--
-- TOC entry 247 (class 1255 OID 195973)
-- Name: add_where_clause_conditions(text, integer, integer, text, text, text[], boolean, text, text, integer, text); Type: FUNCTION; Schema: public; Owner: microaccounts_dev
--

CREATE FUNCTION public.add_where_clause_conditions(_variant_type text, _start_min integer, _end integer, _reference_bases text, _alternate_bases text, _dataset_stable_ids text[], _is_authenticated boolean, _biosample_stable_id text, _individual_stable_id text, _gvariant_id integer, _filters text, OUT _where_clause text) RETURNS text
    LANGUAGE plpgsql
    AS $_$

DECLARE
	_join_variant_table bool;
BEGIN
	_where_clause = '
	WHERE ';
	_join_variant_table = FALSE;
	
	IF _variant_type IS NOT NULL OR _start_min IS NOT NULL OR _end IS NOT NULL 
		OR _reference_bases IS NOT NULL OR _alternate_bases IS NOT NULL
		THEN _join_variant_table = TRUE;
	END IF;

	-- Datasets
	IF NOT _is_authenticated OR _dataset_stable_ids IS NULL OR array_length(_dataset_stable_ids, 1) IS NULL THEN
		-- only query PUBLIC datasets
		_where_clause = _where_clause || '
		dat.access_type=''PUBLIC''';
	END IF;
	
	IF array_length(_dataset_stable_ids, 1) > 0 THEN
		IF NOT _is_authenticated THEN
			_where_clause =  _where_clause || '
			AND';
		END IF;
		_where_clause =  _where_clause || '
		dat.stable_id = ANY($7)';
	END IF;
		
	IF _biosample_stable_id IS NOT NULL THEN
		_where_clause =  _where_clause || '
		AND sam.stable_id=$13';
	END IF;
	
	IF _individual_stable_id IS NOT NULL THEN
		_where_clause =  _where_clause || '
		AND ind.stable_id=$14';
	END IF;
	
	IF _gvariant_id IS NOT NULL THEN
		_where_clause =  _where_clause || '
		AND var.id=$15';
	END IF;
	
	IF _filters IS NOT NULL THEN
		_where_clause = _where_clause || ' 
		AND ' || _filters;
	END IF;

	IF _join_variant_table THEN
	
		IF _variant_type IS NULL AND _alternate_bases IS NULL
		  --THEN RAISE EXCEPTION 'Either _variant_type or _alternate_bases is mandatory';
		  THEN _alternate_bases='*';
		END IF;
		IF _alternate_bases='N' THEN _alternate_bases='*'; END IF; -- Look for any variant	
	
		IF _variant_type IS NOT NULL THEN
			_where_clause = _where_clause || '
			AND var.type=$1';
		END IF;

		IF _start_min IS NOT NULL THEN
			_where_clause = _where_clause || '
			AND var.start >= $9 AND var.start < $10
			AND var.end >= $11	AND var.end < $12';
		ELSIF _alternate_bases != '*' OR (_alternate_bases = '*' AND _end IS NULL)
			OR (_alternate_bases IS NULL AND _variant_type IS NOT NULL) THEN
		  	-- Looking for an exact match
			_where_clause = _where_clause || '
			AND var.start = $2';
		END IF;

		IF _end IS NOT NULL THEN
			-- Remember that end is exclusive
			IF _alternate_bases = '*' THEN
				-- Looking for any variant within this range
				_where_clause = _where_clause || '
				AND (var.start >= $2 AND var.start < $8
				OR var.end >= $2 AND var.end < $8)';
			ELSE
				-- Looking for an exact match
				_where_clause = _where_clause || '
				AND var.end = ($8-1)';
			END IF;
		END IF;

		-- refseq
		_where_clause = _where_clause || '
		AND var.refseq=$3';

		-- Reference parameter is not mandatory
		IF _reference_bases IS NOT NULL AND _reference_bases!='N' THEN
			_where_clause=_where_clause || '
			AND var.reference=$4';
		END IF;

		-- Alternate bases
		IF _alternate_bases IS NOT NULL THEN
		  IF _variant_type='INS' THEN
			  _where_clause = _where_clause || '
			  AND var.alternate like var.reference || $5 || ''%'' ';
			ELSIF _alternate_bases NOT IN ('N','*') THEN
			  _where_clause = _where_clause || '
			  AND var.alternate=$5';
			END IF;
		END IF;

		-- Convert reference_genome column to lower case
		_where_clause = _where_clause || '
		AND lower(dat.reference_genome)=$6';
	END IF;

	-- #1=_variant_type, #2=_start, #3=_refseq, #4=_reference_bases, #5=_alternate_bases, 
	-- #6=_reference_genome, #7=_dataset_stable_ids, #8=_end, #9=_start_min, #10=_start_max, 
	-- #11=_end_min, #12=_end_max, 
	-- #13=_biosample_stable_id, #14=_individual_stable_id, #15=_gvariant_id
	-- #16=_limit, #17=_offset

END
$_$;


ALTER FUNCTION public.add_where_clause_conditions(_variant_type text, _start_min integer, _end integer, _reference_bases text, _alternate_bases text, _dataset_stable_ids text[], _is_authenticated boolean, _biosample_stable_id text, _individual_stable_id text, _gvariant_id integer, _filters text, OUT _where_clause text) OWNER TO microaccounts_dev;

--
-- TOC entry 248 (class 1255 OID 195974)
-- Name: find_format(text[], text, text); Type: FUNCTION; Schema: public; Owner: microaccounts_dev
--

CREATE FUNCTION public.find_format(_requested_schemas text[], _table_name text, _field_name text, OUT _schema_names text, OUT _schema_formats text) RETURNS record
    LANGUAGE plpgsql
    AS $$

DECLARE
	_schema_names_tmp text;
	_schema_formats_tmp text;
BEGIN

	select string_agg(quote_literal(schema_name), ','), string_agg(format, ',') INTO _schema_names_tmp, _schema_formats_tmp
	from schema_table
	where field_name=_field_name AND table_name=_table_name AND
		CASE WHEN _requested_schemas IS NULL OR COALESCE(array_length(_requested_schemas, 1), 0)=0 
		THEN is_default=true
		ELSE schema_name = ANY(_requested_schemas)
		END;
	
	IF _schema_names_tmp IS NULL THEN
		RAISE NOTICE '_schema_names_tmp is null';
		select string_agg(quote_literal(schema_name), ','), string_agg(format, ',') INTO _schema_names_tmp, _schema_formats_tmp
		from schema_table
		where field_name=_field_name AND table_name=_table_name AND is_default=true;
	END IF;
	
	_schema_names = _schema_names_tmp;
	_schema_formats = _schema_formats_tmp;
END
$$;


ALTER FUNCTION public.find_format(_requested_schemas text[], _table_name text, _field_name text, OUT _schema_names text, OUT _schema_formats text) OWNER TO microaccounts_dev;

--
-- TOC entry 249 (class 1255 OID 195975)
-- Name: parse_filters(text[]); Type: FUNCTION; Schema: public; Owner: microaccounts_dev
--

CREATE FUNCTION public.parse_filters(_filters text[], OUT _filters_converted text) RETURNS text
    LANGUAGE plpgsql
    AS $$

BEGIN
	-- _filters format: comma separated list of CURIEs
	-- 		Example: NCIT:C46113,NCIT:C17600,GAZ:00001086

	SELECT string_agg(q.my_filter, ' AND ') INTO _filters_converted
	FROM (
		select target_table_alias || '.' || column_name || operator || quote_literal(column_value) as my_filter
		from (
			SELECT trim(split_part(filter_term,':',1)) AS ontology, 
				trim(split_part(filter_term,':',2)) AS term
			FROM unnest(_filters) AS filter_term
		)q
		LEFT JOIN public.ontology_term_table ot ON ot.ontology=q.ontology AND ot.term=q.term
	)q;
	
	-- Aliases used in ontology_term_table_
	-- 	'ind'
	-- 	'sam'
	-- 	'ind_ped'
	-- 	'ind_dis'
	-- In the future, we may have filters on beacon_data_table
-- 	IF _filters_converted LIKE '%dat.' THEN _join_variant_table=TRUE; END IF;
-- 	IF _filters_converted LIKE '%ind_ped.' THEN _join_individual_pedigree_table=TRUE; END IF;
-- 	IF _filters_converted LIKE '%ind_dis.' THEN _join_individual_disease_table=TRUE; END IF;
-- 	IF _filters_converted LIKE '%ind.' THEN _join_individual_table=TRUE; END IF;

END
$$;


ALTER FUNCTION public.parse_filters(_filters text[], OUT _filters_converted text) OWNER TO microaccounts_dev;

--
-- TOC entry 308 (class 1255 OID 196610)
-- Name: query_gvariants(text, integer, integer, integer, integer, integer, integer, character varying, text, text, text, text, text[], boolean, text, text, integer, text[], integer, integer, text[]); Type: FUNCTION; Schema: public; Owner: microaccounts_dev
--

CREATE FUNCTION public.query_gvariants(_variant_type text, _start integer, _start_min integer, _start_max integer, _end integer, _end_min integer, _end_max integer, _refseq character varying, _reference_bases text, _alternate_bases text, _reference_genome text, _include_dataset_responses text, _dataset_stable_ids text[], _is_authenticated boolean, _biosample_stable_id text, _individual_stable_id text, _gvariant_id integer, _filters text[], _offset integer, _limit integer, _requested_schemas text[]) RETURNS TABLE(variant_id integer, assembly_id text, refseq text, variant_name text, reference text, alternate text, start integer, "end" integer, variant_type text, genomic_hgvs_id text, transcript_hgvs_ids text[], protein_hgvs_ids text[], genomic_regions text[], genomic_regions_ontology text[], genomic_features_ontology addons.hstore[], molecular_effects text[], molecular_effects_ontology text[], aminoacid_changes text[], ontologies_used addons.hstore[], dataset_response jsonb, dataset_response_missing jsonb)
    LANGUAGE plpgsql
    AS $_$

-- PRECONDITIONS:
-- _dataset_stable_ids is optional
-- If _is_authenticated=false or _dataset_stable_ids is empty, only PUBLIC datasets will be queried 
--		(regardless there are registered or controlled in _dataset_stable_ids)
-- If _is_authenticated=true, datasets in _dataset_stable_ids will be queried
-- _offset is the number of rows to be skipped
-- _limit is the number of rows to be returned
-- 	If _limit=null & _offset=null, no pagination is applied
-- Expected combinations:
--		* _reference_genome + _refseq + _alternate_bases + _reference_bases + _start
--		* _reference_genome + _refseq + _alternate_bases + (_reference_bases) + _start + _end
--		* _reference_genome + _refseq + (_variant_type) + _start + _end
--		* _reference_genome + _refseq + (_variant_type) + _start_min + _start_max + _end_min + _end_max

DECLARE
	_query text;
	_where_clause text;
	_filters_converted text;
	_join_individual_table bool;
	_join_sample_table bool;
	_join_individual_pedigree_table bool;
	_join_individual_disease_table bool;
	_join_individual_phenotypic_feature_table bool;
	_only_hit_datasets bool;
	_only_miss_datasets bool;
	_none_dataset bool;
	-- Schemas and formats for some fields
	_genomic_features_schema_names text;
	_genomic_features_schema_formats text;
	_genomic_features_ontologies_used_schema_names text;
	_genomic_features_ontologies_used_schema_formats text;
BEGIN
	_join_individual_table = FALSE;
	_join_sample_table = FALSE;
	_join_individual_pedigree_table = FALSE;
	_join_individual_disease_table = FALSE;
	_join_individual_phenotypic_feature_table = FALSE;

	_only_hit_datasets = FALSE;
	_only_miss_datasets = FALSE;
	_none_dataset = FALSE;
	
	IF _include_dataset_responses = 'HIT' THEN
		_only_hit_datasets = TRUE;
	END IF;
	IF _include_dataset_responses = 'MISS' THEN
		_only_miss_datasets = TRUE;
	END IF;
	IF _include_dataset_responses = 'NONE' THEN
		_none_dataset = TRUE;
	END IF;

	SELECT * INTO _filters_converted
	FROM public.parse_filters(_filters);

	-- Aliases used in ontology_term_table
	-- 	'ind'
	-- 	'sam'
	-- 	'ind_ped'
	-- 	'ind_dis'
	-- In the future, we may have filters on variant_table
	
	-- Check what other tables should be joined depending on the filters provided
	-- TODO

	SELECT * INTO _where_clause
	FROM public.add_where_clause_conditions(_variant_type, _start_min, _end, _reference_bases, 
											_alternate_bases, _dataset_stable_ids, _is_authenticated, 
											_biosample_stable_id, _individual_stable_id, _gvariant_id, 
											_filters_converted);
											
	RAISE NOTICE 'WHERE=%', _where_clause;
	
	IF _where_clause LIKE '%ind.%' 
		OR _where_clause LIKE '%ind_ped.%' 
		OR _where_clause LIKE '%ind_dis.%' 
		OR _where_clause LIKE '%ind_phf.%' 
	THEN 
		_join_sample_table=TRUE;
		_join_individual_table=TRUE; 
	END IF;
	IF _where_clause LIKE '%sam.%' THEN _join_sample_table=TRUE; END IF;
	IF _where_clause LIKE '%ind_ped.%' THEN _join_individual_pedigree_table=TRUE; END IF;
	IF _where_clause LIKE '%ind_dis.%' THEN _join_individual_disease_table=TRUE; END IF;
	IF _where_clause LIKE '%ind_phf.%' THEN _join_individual_phenotypic_feature_table=TRUE; END IF;
	
	RAISE NOTICE 'Parameters:  
		_variant_type=%, 
		_start=%, _start_min=%, _start_max=%, 
		_end=%, _end_min=%, _end_max=%,
		_refseq=%, _reference_bases=%, _alternate_bases=%, _reference_genome=%, 
		_dataset_stable_ids=%, _is_authenticated=%, 
		_filters=%, _filters_converted=%,
		_biosample_stable_id=%, _individual_stable_id=%,
		_include_dataset_responses=%, 
		_limit=%, _offset=%', 
	_variant_type, _start, _start_min, _start_max, _end, _end_min, _end_max,
	_refseq, _reference_bases, _alternate_bases, _reference_genome, 
	_dataset_stable_ids, _is_authenticated, _filters, _filters_converted, 
	_biosample_stable_id, _individual_stable_id, 
	_include_dataset_responses,
	_limit, _offset;
	
	---------------------------------
	-- Get the schemas and formats --
	---------------------------------
	SELECT COALESCE(_schema_names, '-'), COALESCE(_schema_formats, '-') INTO _genomic_features_schema_names, _genomic_features_schema_formats
	FROM public.find_format(_requested_schemas,'public.variant_table','genomic_features_ontology');

	IF _genomic_features_schema_names='-' THEN RAISE EXCEPTION 'Requested schemas not found! %', _requested_schemas; END IF;
	
	SELECT COALESCE(_schema_names, '-'), COALESCE(_schema_formats, '-') 
		INTO _genomic_features_ontologies_used_schema_names, _genomic_features_ontologies_used_schema_formats
	FROM public.find_format(_requested_schemas,'public.variant_table','genomic_features_resources');
	
	IF _genomic_features_ontologies_used_schema_names='-' THEN 
		_genomic_features_ontologies_used_schema_names = ''; 
		_genomic_features_ontologies_used_schema_formats = '';
	END IF;
	
	---------------------
	-- BUILD THE QUERY --
	---------------------
	_query = '
	SELECT --var.exists,
		var.id AS variant_id,
		var.assembly_id,
		var.refseq, 
		var.variant_id AS alternative_id, 
		var.reference, 
		var.alternate, 
		var.start, 
		var.end, 
		var.variant_type, 
		var.genomic_hgvs_id, --10
		var.transcript_hgvs_ids,
		var.protein_hgvs_ids,
		var.genomic_regions,
		var.genomic_regions_ontology,
		var.genomic_features_ontology, --15
		var.molecular_effects,
		var.molecular_effects_ontology,
		var.aminoacid_changes,
		var.ontologies_used,
		CASE WHEN ' || _only_miss_datasets || ' OR ' || _none_dataset || '
			THEN ''{}''::jsonb
			ELSE COALESCE(var.datasets_response, ''[]''::jsonb)
		END AS datasets_response,
		CASE WHEN ' || _only_hit_datasets || ' OR ' || _none_dataset || '
			THEN ''[]''::jsonb
			ELSE
				COALESCE(jsonb_agg(
					DISTINCT
					jsonb_build_object(
						''datasetId'',dat_missing.stable_id,
						''exists'', FALSE,
				 		''frequency'', null,
				 		''variantCount'', null,
				 		''callCount'', null,
				 		''sampleCount'', null,
				 		''note'', null,
				 		''externalUrl'', null,
				 		''datasetHandover'', null,
				 		''info'', null
					) 
				) FILTER (WHERE dat_missing.stable_id IS NOT NULL), ''[]''::jsonb) 
		END AS datasets_response_missing --20
	FROM (
		SELECT DISTINCT
				--TRUE AS exists,
				var.id,
				dat.reference_genome::text AS assembly_id,
				var.refseq::text, 
				var.variant_id::text, 
				var.reference::text, 
				var.alternate::text, 
				var.start, 
				var.end, 
				var.type::text AS variant_type, 
				var.genomic_hgvs_id,
				var.transcript_hgvs_ids,
				var.protein_hgvs_ids,
				var.genomic_regions,
				null::text[] AS genomic_regions_ontology,
				COALESCE(array_agg(DISTINCT gf.genomic_features_ontology) FILTER (WHERE gf.genomic_features_ontology IS NOT NULL), ''{}''::addons.hstore[]) AS genomic_features_ontology,
				COALESCE(array_agg(DISTINCT gf.ontologies_used) FILTER (WHERE gf.ontologies_used IS NOT NULL), ''{}''::addons.hstore[]) AS ontologies_used,
				var.molecular_effects,
				null::text[] AS molecular_effects_ontology,
				var.aminoacid_changes,
				jsonb_agg(
					DISTINCT
					jsonb_build_object(
						''datasetId'',dat.stable_id,
						''exists'',TRUE,
						''frequency'',var.frequency,
						''variantCount'',var.variant_cnt,
						''callCount'',var.call_cnt,
						''sampleCount'',var.sample_cnt,
						''note'', null,
						''externalUrl'', null,
						''datasetHandover'', null,
						''info'', jsonb_build_object(
							''matchingSampleCount'',var.matching_sample_cnt
						)
					)
				) AS datasets_response,
				array_agg(dat.id) AS dataset_ids
			FROM public.variant_table var
			INNER JOIN public.dataset_table dat ON dat.id=var.dataset_id';
			
		_query = _query || '
			LEFT JOIN LATERAL (
				SELECT 
					addons.hstore(ARRAY[' || _genomic_features_schema_names || '],ARRAY[' || _genomic_features_schema_formats || ']) 
						AS genomic_features_ontology,
					addons.hstore(ARRAY[' || _genomic_features_ontologies_used_schema_names || ']::text[],ARRAY[' || _genomic_features_ontologies_used_schema_formats || ']::text[]) 
						AS ontologies_used
				FROM unnest(var.gene_names, var.transcript_ids) AS t(gene_name, transcript_id)
				join lateral (
					values 
						(t.gene_name, ''gene''), 
						(t.transcript_id, ''transcript'') 
				) as v(gene_or_transcript, label) on true
				LEFT JOIN public.ontology_term_table ot ON ot.target_table=''public.variant_table'' AND ot.column_name=''genomicFeatures'' AND ot.label=v.label
				LEFT JOIN public.ontology_table ot_ontology ON ot_ontology.id=ot.ontology_id
				where v.gene_or_transcript is not null
			) gf ON TRUE';
		
	IF _join_sample_table THEN
		_query = _query || '
		INNER JOIN public.variant_sample_table var_sam ON var_sam.variant_id=var.id
		INNER JOIN public.sample_table sam ON sam.id=var_sam.sample_id';
	END IF;
	IF _join_individual_table THEN
		_query = _query || '
		INNER JOIN public.individual_table ind ON ind.id=sam.individual_id';
	END IF;
	IF _join_individual_pedigree_table THEN
		_query = _query || '
		INNER JOIN public.individual_pedigree_table ind_ped ON ind_ped.individual_id=ind.id';
	END IF;
	IF _join_individual_disease_table THEN
		_query = _query || '
		INNER JOIN public.individual_disease_table ind_dis ON ind_dis.individual_id=ind.id';
	END IF;
	IF _join_individual_phenotypic_feature_table THEN
		_query = _query || '
		INNER JOIN public.individual_phenotypic_feature_w_ontology_terms ind_phf ON ind_phf.individual_id=ind.id';
	END IF;
		
	_query = _query || _where_clause;
	
	_query = _query || '
		GROUP BY 
				var.id,
				dat.reference_genome,
				var.refseq::text, 
				var.variant_id::text, 
				var.reference::text, 
				var.alternate::text, 
				var.start, 
				var.end, 
				var.type::text, 
				var.genomic_hgvs_id,
				var.transcript_hgvs_ids,
				var.protein_hgvs_ids,
				var.genomic_regions,
				var.molecular_effects,
				var.aminoacid_changes
		ORDER BY var.id';
		-- Apply pagination
		_query = _query || '
		LIMIT $16 OFFSET $17';

	_query = _query || '	
	)var
	LEFT JOIN LATERAL (
		SELECT dat.stable_id
		FROM public.dataset_table dat 
		WHERE NOT(dat.id  = ANY (var.dataset_ids))
	)dat_missing ON TRUE
	GROUP BY 
		var.id,
		var.assembly_id,
		var.refseq, 
		var.variant_id, 
		var.reference, 
		var.alternate, 
		var.start, 
		var.end, 
		var.variant_type, 
		var.genomic_hgvs_id,
		var.transcript_hgvs_ids,
		var.protein_hgvs_ids,
		var.genomic_regions,
		var.genomic_regions_ontology,
		var.genomic_features_ontology,
		var.ontologies_used,
		var.molecular_effects,
		var.molecular_effects_ontology,
		var.aminoacid_changes,
		var.datasets_response
	ORDER BY 
		var.id';

	RAISE NOTICE '_query: %', _query;

	RETURN QUERY EXECUTE _query
	USING _variant_type, _start, _refseq, _reference_bases, _alternate_bases, 
		_reference_genome, _dataset_stable_ids, _end, _start_min, _start_max, _end_min, _end_max, 
		_biosample_stable_id, _individual_stable_id, _gvariant_id, _limit, _offset;
	-- #1=_variant_type, #2=_start, #3=_refseq, #4=_reference_bases, #5=_alternate_bases, 
	-- #6=_reference_genome, #7=_dataset_stable_ids, #8=_end, #9=_start_min, #10=_start_max, 
	-- #11=_end_min, #12=_end_max, 
	-- #13=_biosample_stable_id, #14=_individual_stable_id, #15=_gvariant_id,
	-- #16=_limit, #17=_offset
END
$_$;


ALTER FUNCTION public.query_gvariants(_variant_type text, _start integer, _start_min integer, _start_max integer, _end integer, _end_min integer, _end_max integer, _refseq character varying, _reference_bases text, _alternate_bases text, _reference_genome text, _include_dataset_responses text, _dataset_stable_ids text[], _is_authenticated boolean, _biosample_stable_id text, _individual_stable_id text, _gvariant_id integer, _filters text[], _offset integer, _limit integer, _requested_schemas text[]) OWNER TO microaccounts_dev;

--
-- TOC entry 307 (class 1255 OID 196642)
-- Name: query_individuals(text, integer, integer, integer, integer, integer, integer, character varying, text, text, text, text[], boolean, text, text, integer, text[], integer, integer, text[]); Type: FUNCTION; Schema: public; Owner: microaccounts_dev
--

CREATE FUNCTION public.query_individuals(_variant_type text, _start integer, _start_min integer, _start_max integer, _end integer, _end_min integer, _end_max integer, _refseq character varying, _reference_bases text, _alternate_bases text, _reference_genome text, _dataset_stable_ids text[], _is_authenticated boolean, _biosample_stable_id text, _individual_stable_id text, _gvariant_id integer, _filters text[], _offset integer, _limit integer, _requested_schemas text[]) RETURNS TABLE(individual_stable_id text, taxon_id text, taxon_id_ontology text, taxon_id_ontology_label text, sex text, sex_ontology text, ethnicity text, ethnicity_ontology text, geographic_origin text, geographic_origin_ontology text, pedigrees addons.hstore[], diseases addons.hstore[], phenotypic_features addons.hstore[], ontologies_used addons.hstore[])
    LANGUAGE plpgsql
    AS $_$

-- PRECONDITIONS:
-- _dataset_stable_ids is optional
-- If _is_authenticated=false or _dataset_stable_ids is empty, only PUBLIC datasets will be queried 
--		(regardless there are registered or controlled in _dataset_stable_ids)
-- If _is_authenticated=true, datasets in _dataset_stable_ids will be queried
-- _offset is the number of rows to be skipped
-- _limit is the number of rows to be returned
-- 	If _limit=null & _offset=null, no pagination is applied
-- Expected combinations:
--		* _reference_genome + _refseq + _alternate_bases + _reference_bases + _start
--		* _reference_genome + _refseq + _alternate_bases + (_reference_bases) + _start + _end
--		* _reference_genome + _refseq + (_variant_type) + _start + _end
--		* _reference_genome + _refseq + (_variant_type) + _start_min + _start_max + _end_min + _end_max

DECLARE
	_query text;
	_where_clause text;
	_filters_converted text;
	_join_variant_table bool;
	-- Schemas and formats for some fields
	_phf_schema_names text;
	_phf_schema_formats text;
	_dis_schema_names text;
	_dis_schema_formats text;
	_ped_schema_names text;
	_ped_schema_formats text;
	_individual_resources_schema_names text;
	_individual_resources_schema_formats text;
BEGIN
	_join_variant_table = FALSE;

	SELECT * INTO _filters_converted
	FROM public.parse_filters(_filters);

	-- Aliases used in ontology_term_table
	-- 	'ind'
	-- 	'sam'
	-- 	'ind_ped'
	-- 	'ind_dis'
	-- In the future, we may have filters on variant_table
	
	-- Check what other tables should be joined depending on the filters provided
	IF _filters_converted LIKE '%var.%' THEN _join_variant_table=TRUE; END IF;
	
	SELECT * INTO _where_clause
	FROM public.add_where_clause_conditions(_variant_type, _start_min, _end, _reference_bases, 
											_alternate_bases, _dataset_stable_ids, _is_authenticated, 
											_biosample_stable_id, _individual_stable_id, _gvariant_id, 
											_filters_converted);
											
	RAISE NOTICE 'WHERE=%', _where_clause;
											
	IF _where_clause LIKE '%var.%' THEN _join_variant_table=TRUE; END IF;
	
	RAISE NOTICE 'Parameters:  
		_variant_type=%, 
		_start=%, _start_min=%, _start_max=%, 
		_end=%, _end_min=%, _end_max=%,
		_refseq=%, _reference_bases=%, _alternate_bases=%, _reference_genome=%, 
		_dataset_stable_ids=%, _is_authenticated=%, 
		_filters=%, _filters_converted=%,
		_biosample_stable_id=%, _individual_stable_id=%,
		_limit=%, _offset=%, _join_variant_table=%', 
	_variant_type, _start, _start_min, _start_max, _end, _end_min, _end_max,
	_refseq, _reference_bases, _alternate_bases, _reference_genome, 
	_dataset_stable_ids, _is_authenticated, _filters, _filters_converted, 
	_biosample_stable_id, _individual_stable_id, 
	_limit, _offset, _join_variant_table;
	
	---------------------------------
	-- Get the schemas and formats --
	---------------------------------
	SELECT COALESCE(_schema_names, '-'), COALESCE(_schema_formats, '-') INTO _phf_schema_names, _phf_schema_formats
	FROM public.find_format(_requested_schemas,'public.individual_table','phenotypic_features');

	IF _phf_schema_names='-' THEN RAISE EXCEPTION 'Requested schemas not found! %', _requested_schemas; END IF;

	SELECT COALESCE(_schema_names, '-'), COALESCE(_schema_formats, '-') INTO _dis_schema_names, _dis_schema_formats
	FROM public.find_format(_requested_schemas,'public.individual_table','diseases');

	IF _dis_schema_names='-' THEN RAISE EXCEPTION 'Requested schemas not found! %', _requested_schemas; END IF;
	
	SELECT COALESCE(_schema_names, '-'), COALESCE(_schema_formats, '-') INTO _ped_schema_names, _ped_schema_formats
	FROM public.find_format(_requested_schemas,'public.individual_table','pedigrees');

	IF _ped_schema_names='-' THEN RAISE EXCEPTION 'Requested schemas not found! %', _requested_schemas; END IF;
	
	SELECT COALESCE(_schema_names, '-'), COALESCE(_schema_formats, '-') INTO _individual_resources_schema_names, _individual_resources_schema_formats
	FROM public.find_format(_requested_schemas,'public.individual_table','individual_resources');

	IF _individual_resources_schema_names='-' THEN 
		_individual_resources_schema_names = ''; 
		_individual_resources_schema_formats = '';
	END IF;
	
	---------------------
	-- BUILD THE QUERY --
	---------------------
	_query = '
		SELECT 
			ind.stable_id AS individual_id,
			ind.taxon_id AS taxon_id,
			ind.taxon_id_ontology AS taxon_id_ontology,
			ind.taxon_id_ontology_label,
			ind.sex AS sex,
			ind.sex_ontology AS sex_ontology,
			ind.ethnicity AS ethnicity,
			ind.ethnicity_ontology AS ethnicity_ontology,
			ind.geographic_origin AS geographic_origin,
			ind.geographic_origin_ontology AS geographic_origin_ontology,
			COALESCE(array_agg(DISTINCT ind_ped2.pedigrees) FILTER (WHERE ind_ped2.pedigrees IS NOT NULL), ''{}''::addons.hstore[]) AS pedigrees,
			COALESCE(array_agg(DISTINCT ind_dis2.diseases) FILTER (WHERE ind_dis2.diseases IS NOT NULL), ''{}''::addons.hstore[]) AS diseases,
			COALESCE(array_agg(DISTINCT ind_phf2.phenotypic_features) FILTER (WHERE ind_phf2.phenotypic_features IS NOT NULL), ''{}''::addons.hstore[]) AS phenotypic_features,
			COALESCE(array_agg(DISTINCT ontologies.used) FILTER (WHERE ontologies.used IS NOT NULL), ''{}''::addons.hstore[]) AS ontologies_used
		FROM public.individual_w_ontology_terms ind 
		INNER JOIN public.sample_table sam ON sam.individual_id=ind.id
		INNER JOIN public.dataset_sample_table dataset_sam ON dataset_sam.sample_id=sam.id
		INNER JOIN public.dataset_table dat ON dat.id = dataset_sam.dataset_id
		LEFT JOIN public.individual_pedigree_w_ontology_terms ind_ped ON ind_ped.individual_id=ind.id
		LEFT JOIN public.individual_disease_w_ontology_terms ind_dis ON ind_dis.individual_id=ind.id
		LEFT JOIN public.individual_phenotypic_feature_w_ontology_terms ind_phf ON ind_phf.individual_id=ind.id';
	
	-- Join other tables only if they are necessary
	IF _join_variant_table THEN
		_query = _query || '
		INNER JOIN public.variant_sample_table var_sam ON var_sam.sample_id=sam.id
		INNER JOIN public.variant_table var ON var.id=var_sam.variant_id AND var.dataset_id=dat.id';
	END IF;
	
	-- Add LEFT JOINs
	_query = _query || '
		LEFT JOIN LATERAL (
			SELECT addons.hstore(ARRAY[' || _ped_schema_names || '],ARRAY[' || _ped_schema_formats || ']) 
				AS pedigrees
			FROM public.individual_pedigree_w_ontology_terms ind_ped 
			WHERE ind_ped.individual_id=ind.id
		) ind_ped2 ON TRUE
		LEFT JOIN LATERAL (
			SELECT addons.hstore(ARRAY[' || _dis_schema_names || '], ARRAY[' || _dis_schema_formats || ']) 
					AS diseases,
				addons.hstore(ARRAY[' || _individual_resources_schema_names || ']::text[], ARRAY[' || _individual_resources_schema_formats || ']::text[])
					AS ontologies_used
			FROM public.individual_disease_w_ontology_terms ind_dis 
			LEFT JOIN public.ontology_table disease_ontology ON disease_ontology.id=ind_dis.disease_ontology_id
			LEFT JOIN public.ontology_table age_group_ontology ON age_group_ontology.id=ind_dis.age_group_ontology_id
			LEFT JOIN public.ontology_table stage_ontology ON stage_ontology.id=ind_dis.stage_ontology_id
			LEFT JOIN public.ontology_table onset_type_ontology ON onset_type_ontology.id=ind_dis.onset_type_ontology_id
			LEFT JOIN LATERAL (
				values 
				(disease_ontology.ontology_id, disease_ontology.ontology_name, disease_ontology.namespace_prefix,
				disease_ontology.url, disease_ontology.version, disease_ontology.iri_prefix),
				(age_group_ontology.ontology_id, age_group_ontology.ontology_name, age_group_ontology.namespace_prefix,
				age_group_ontology.url, age_group_ontology.version, age_group_ontology.iri_prefix),
				(stage_ontology.ontology_id, stage_ontology.ontology_name, stage_ontology.namespace_prefix,
				stage_ontology.url, stage_ontology.version, stage_ontology.iri_prefix),
				(onset_type_ontology.ontology_id, onset_type_ontology.ontology_name, onset_type_ontology.namespace_prefix,
				onset_type_ontology.url, onset_type_ontology.version, onset_type_ontology.iri_prefix)
			)	AS ot(ontology_id, ontology_name, namespace_prefix, url, version, iri_prefix) ON TRUE
			WHERE ind_dis.individual_id=ind.id
		) ind_dis2 ON TRUE
		LEFT JOIN LATERAL (
			SELECT addons.hstore(ARRAY[' || _phf_schema_names || '],ARRAY[' || _phf_schema_formats || ']) 
				AS phenotypic_features,
				addons.hstore(ARRAY[' || _individual_resources_schema_names || ']::text[], ARRAY[' || _individual_resources_schema_formats || ']::text[])
					AS ontologies_used
			FROM public.individual_phenotypic_feature_w_ontology_terms ind_phf 
			LEFT JOIN public.ontology_table phenotype_ontology ON phenotype_ontology.id=ind_phf.phenotype_ontology_id
			LEFT JOIN public.ontology_table onset_type_ontology ON onset_type_ontology.id=ind_phf.onset_type_ontology_id
			LEFT JOIN public.ontology_table age_group_ontology ON age_group_ontology.id=ind_phf.age_group_ontology_id
			LEFT JOIN public.ontology_table severity_ontology ON severity_ontology.id=ind_phf.severity_ontology_id
			LEFT JOIN LATERAL (
				values 
				(phenotype_ontology.ontology_id, phenotype_ontology.ontology_name, phenotype_ontology.namespace_prefix,
				phenotype_ontology.url, phenotype_ontology.version, phenotype_ontology.iri_prefix),
				(onset_type_ontology.ontology_id, onset_type_ontology.ontology_name, onset_type_ontology.namespace_prefix,
				onset_type_ontology.url, onset_type_ontology.version, age_group_ontology.iri_prefix),
				(age_group_ontology.ontology_id, age_group_ontology.ontology_name, age_group_ontology.namespace_prefix,
				age_group_ontology.url, age_group_ontology.version, age_group_ontology.iri_prefix),
				(severity_ontology.ontology_id, severity_ontology.ontology_name, severity_ontology.namespace_prefix,
				severity_ontology.url, severity_ontology.version, severity_ontology.iri_prefix)
			)	AS ot(ontology_id, ontology_name, namespace_prefix, url, version, iri_prefix) ON TRUE
			WHERE ind_phf.individual_id=ind.id
		) ind_phf2 ON TRUE
		LEFT JOIN LATERAL (
			SELECT addons.hstore(ARRAY[' || _individual_resources_schema_names || ']::text[],ARRAY[' || _individual_resources_schema_formats || ']::text[]) 
				AS ontologies_used
			FROM public.ontology_table ot 
			WHERE ot.id=ind.taxon_ontology_id
			UNION
			SELECT addons.hstore(ARRAY[' || _individual_resources_schema_names || ']::text[],ARRAY[' || _individual_resources_schema_formats || ']::text[]) 
				AS ontologies_used
			FROM public.ontology_table ot 
			WHERE ot.id=ind.sex_ontology_id
		) taxon_sex_ontology ON TRUE
		LEFT JOIN LATERAL (
			VALUES 
			(taxon_sex_ontology.ontologies_used), 
			(ind_dis2.ontologies_used),
			(ind_phf2.ontologies_used)
		) AS ontologies(used) ON TRUE
		';

	_query = _query || _where_clause;
	
	_query = _query || ' 
		GROUP BY ind.stable_id,
			ind.taxon_id,
			ind.taxon_id_ontology,
			ind.taxon_id_ontology_label,
			ind.sex,
			ind.sex_ontology,
			ind.ethnicity,
			ind.ethnicity_ontology,
			ind.geographic_origin,
			ind.geographic_origin_ontology
 		ORDER BY ind.stable_id,
 			ind.sex,
 			ind.sex_ontology,
 			ind.ethnicity,
 			ind.ethnicity_ontology,
 			ind.geographic_origin,
 			ind.geographic_origin_ontology
 			';
	
	-- Apply pagination
	_query = _query || '
		LIMIT $16 OFFSET $17';

	RAISE NOTICE '_query: %', _query;

	RETURN QUERY EXECUTE _query
	USING _variant_type, _start, _refseq, _reference_bases, _alternate_bases, 
		_reference_genome, _dataset_stable_ids, _end, _start_min, _start_max, _end_min, _end_max, 
		_biosample_stable_id, _individual_stable_id, _gvariant_id, 
		_limit, _offset;
	-- #1=_variant_type, #2=_start, #3=_refseq, #4=_reference_bases, #5=_alternate_bases, 
	-- #6=_reference_genome, #7=_dataset_stable_ids, #8=_end, #9=_start_min, #10=_start_max, 
	-- #11=_end_min, #12=_end_max, 
	-- #13=_biosample_stable_id, #14=_individual_stable_id, #15=_gvariant_id,
	-- #16=_limit, #17=_offset
END
$_$;


ALTER FUNCTION public.query_individuals(_variant_type text, _start integer, _start_min integer, _start_max integer, _end integer, _end_min integer, _end_max integer, _refseq character varying, _reference_bases text, _alternate_bases text, _reference_genome text, _dataset_stable_ids text[], _is_authenticated boolean, _biosample_stable_id text, _individual_stable_id text, _gvariant_id integer, _filters text[], _offset integer, _limit integer, _requested_schemas text[]) OWNER TO microaccounts_dev;

--
-- TOC entry 306 (class 1255 OID 196591)
-- Name: query_samples(text, integer, integer, integer, integer, integer, integer, character varying, text, text, text, text[], boolean, text, text, integer, text[], integer, integer, text[]); Type: FUNCTION; Schema: public; Owner: microaccounts_dev
--

CREATE FUNCTION public.query_samples(_variant_type text, _start integer, _start_min integer, _start_max integer, _end integer, _end_min integer, _end_max integer, _refseq character varying, _reference_bases text, _alternate_bases text, _reference_genome text, _dataset_stable_ids text[], _is_authenticated boolean, _biosample_stable_id text, _individual_stable_id text, _gvariant_id integer, _filters text[], _offset integer, _limit integer, _requested_schemas text[]) RETURNS TABLE(biosample_stable_id text, individual_stable_id text, description text, biosample_status text, biosample_status_ontology text, biosample_status_ontology_label text, individual_age_at_collection text, obtention_procedure text, obtention_procedure_ontology text, obtention_procedure_ontology_label text, tumor_progression text, tumor_progression_ontology text, tumor_progression_ontology_label text, tumor_grade text, tumor_grade_ontology text, tumor_grade_ontology_label text, collection_date date, sample_origins jsonb, sample_origins_ontology addons.hstore[], ontologies_used addons.hstore[])
    LANGUAGE plpgsql
    AS $_$

-- PRECONDITIONS:
-- _dataset_stable_ids is optional
-- If _is_authenticated=false or _dataset_stable_ids is empty, only PUBLIC datasets will be queried 
--		(regardless there are registered or controlled in _dataset_stable_ids)
-- If _is_authenticated=true, datasets in _dataset_stable_ids will be queried
-- _offset is the number of rows to be skipped
-- _limit is the number of rows to be returned
-- 	If _limit=null & _offset=null, no pagination is applied
-- Expected combinations:
--		* _reference_genome + _refseq + _alternate_bases + _reference_bases + _start
--		* _reference_genome + _refseq + _alternate_bases + (_reference_bases) + _start + _end
--		* _reference_genome + _refseq + (_variant_type) + _start + _end
--		* _reference_genome + _refseq + (_variant_type) + _start_min + _start_max + _end_min + _end_max

DECLARE
	_query text;
	_where_clause text;
	_filters_converted text;
	_join_variant_table bool;
	_join_individual_pedigree_table bool;
	_join_individual_disease_table bool;
	_join_individual_phenotypic_feature_table bool;
	-- Schemas and formats for some fields
	_origins_schema_names text;
	_origins_schema_formats text;
	_origins_ontologies_used_schema_names text;
	_origins_ontologies_used_schema_formats text;
BEGIN
	_join_variant_table = FALSE;
	_join_individual_pedigree_table = FALSE;
	_join_individual_disease_table = FALSE;
	_join_individual_phenotypic_feature_table = FALSE;

	SELECT * INTO _filters_converted
	FROM public.parse_filters(_filters);

	-- Aliases used in ontology_term_table
	-- 	'ind'
	-- 	'sam'
	-- 	'ind_ped'
	-- 	'ind_dis'
	-- In the future, we may have filters on variant_table
	
	-- Check what other tables should be joined depending on the filters provided
	IF _filters_converted LIKE '%var.%' THEN _join_variant_table=TRUE; END IF;
	IF _filters_converted LIKE '%ind_ped.%' THEN _join_individual_pedigree_table=TRUE; END IF;
	IF _filters_converted LIKE '%ind_dis.%' THEN _join_individual_disease_table=TRUE; END IF;
	IF _filters_converted LIKE '%ind_phf.%' THEN _join_individual_phenotypic_feature_table=TRUE; END IF;

	SELECT * INTO _where_clause
	FROM public.add_where_clause_conditions(_variant_type, _start_min, _end, _reference_bases, 
											_alternate_bases, _dataset_stable_ids, _is_authenticated, 
											_biosample_stable_id, _individual_stable_id, _gvariant_id,
											_filters_converted);
											
	RAISE NOTICE 'WHERE=%', _where_clause;
											
	IF _where_clause LIKE '%var.%' THEN _join_variant_table=TRUE; END IF;
	
	RAISE NOTICE 'Parameters:  
		_variant_type=%, 
		_start=%, _start_min=%, _start_max=%, 
		_end=%, _end_min=%, _end_max=%,
		_refseq=%, _reference_bases=%, _alternate_bases=%, _reference_genome=%, 
		_dataset_stable_ids=%, _is_authenticated=%, 
		_filters=%, _filters_converted=%,
		_biosample_stable_id=%, _individual_stable_id=%,
		_limit=%, _offset=%, _join_variant_table=%', 
	_variant_type, _start, _start_min, _start_max, _end, _end_min, _end_max,
	_refseq, _reference_bases, _alternate_bases, _reference_genome, 
	_dataset_stable_ids, _is_authenticated, _filters, _filters_converted, 
	_biosample_stable_id, _individual_stable_id, 
	_limit, _offset, _join_variant_table;
	
	---------------------------------
	-- Get the schemas and formats --
	---------------------------------
	SELECT COALESCE(_schema_names, '-'), COALESCE(_schema_formats, '-') INTO _origins_schema_names, _origins_schema_formats
	FROM public.find_format(_requested_schemas,'public.sample_table','sample_origins_ontology');
	
	IF _origins_schema_names='-' THEN RAISE EXCEPTION 'Requested schemas not found! %', _requested_schemas; END IF;
	
	SELECT COALESCE(_schema_names, '-'), COALESCE(_schema_formats, '-') 
		INTO _origins_ontologies_used_schema_names, _origins_ontologies_used_schema_formats
	FROM public.find_format(_requested_schemas,'public.sample_table','sample_origins_resources');
	
	IF _origins_ontologies_used_schema_names='-' THEN 
		_origins_ontologies_used_schema_names = ''; 
		_origins_ontologies_used_schema_formats = '';
	END IF;
	
	---------------------
	-- BUILD THE QUERY --
	---------------------
	_query = '
		SELECT DISTINCT
			sam.stable_id AS biosample_stable_id,
			ind.stable_id AS individual_stable_id,
			sam.description,
			sam.biosample_status,
			sam.biosample_status_ontology,
			sam.biosample_status_ontology_label,
			sam.individual_age_at_collection,
			sam.obtention_procedure,
			sam.obtention_procedure_ontology,
			sam.obtention_procedure_ontology_label,
			sam.tumor_progression,
			sam.tumor_progression_ontology,
			sam.tumor_progression_ontology_label,
			sam.tumor_grade,
			sam.tumor_grade_ontology,
			sam.tumor_grade_ontology_label,
			sam.collection_date,
			sam.sample_origins,
			COALESCE(array_agg(DISTINCT sam_origins.sample_origin_descriptors) FILTER (WHERE sam_origins.sample_origin_descriptors IS NOT NULL), ''{}''::addons.hstore[]) AS sample_origins_ontology,
			--sam_origins.sample_origin_descriptors AS sample_origins_ontology
			COALESCE(array_agg(DISTINCT sam_origins.ontologies_used) FILTER (WHERE sam_origins.ontologies_used IS NOT NULL), ''{}''::addons.hstore[]) AS ontologies_used
		FROM public.sample_w_ontology_terms sam
		INNER JOIN public.individual_w_ontology_terms ind ON ind.id=sam.individual_id
		INNER JOIN public.dataset_sample_table dataset_sam ON dataset_sam.sample_id=sam.id
		INNER JOIN public.dataset_table dat ON dat.id = dataset_sam.dataset_id';
	
	-- Join other tables only if they are necessary	
	IF _join_variant_table THEN
		_query = _query || '
		INNER JOIN public.variant_sample_table var_sam ON var_sam.sample_id=sam.id
		INNER JOIN public.variant_table var ON var.id=var_sam.variant_id';
	END IF;
	
	IF _join_individual_pedigree_table THEN
		_query = _query || '
		INNER JOIN public.individual_pedigree_w_ontology_terms ind_ped ON ind_ped.individual_id=ind.id';
	END IF;
	
	IF _join_individual_disease_table THEN
		_query = _query || '
		INNER JOIN public.individual_disease_w_ontology_terms ind_dis ON ind_dis.individual_id=ind.id';
	END IF;
	
	IF _join_individual_phenotypic_feature_table THEN
		_query = _query || '
		INNER JOIN public.individual_phenotypic_feature_w_ontology_terms ind_phf ON ind_phf.individual_id=ind.id';
	END IF;
	
	-- Add LEFT JOINS
	_query = _query || '
	LEFT JOIN LATERAL (
		SELECT addons.hstore(ARRAY[' || _origins_schema_names || '],ARRAY[' || _origins_schema_formats || ']) AS sample_origin_descriptors,
			addons.hstore(ARRAY[' || _origins_ontologies_used_schema_names || ']::text[],ARRAY[' || _origins_ontologies_used_schema_formats || ']::text[]) AS ontologies_used
		FROM jsonb_array_elements(sam.sample_origins) AS sam_origins(data)
		LEFT JOIN public.ontology_term_table ot_origin_type ON ot_origin_type.target_table=''public.sample_table'' AND ot_origin_type.column_name=''sampleOriginType'' 
				AND lower(ot_origin_type.column_value)=lower(sam_origins.data->>''sampleOriginType'')
		LEFT JOIN public.ontology_term_table ot_origin_detail ON ot_origin_detail.target_table=''public.sample_table'' AND ot_origin_detail.column_name=''sampleOriginDetail'' 
			AND lower(ot_origin_detail.column_value)=lower(sam_origins.data->>''sampleOriginDetail'')
		LEFT JOIN public.ontology_table ot_origin_detail_ontology ON ot_origin_detail_ontology.id=ot_origin_detail.ontology_id
		ORDER BY 
			sam_origins.data->>''sampleOriginType'',
			sam_origins.data->>''sampleOriginDetail''
	)sam_origins ON TRUE';
	
	_query = _query || _where_clause;
	
	_query = _query || ' 
	GROUP BY sam.stable_id,
			ind.stable_id,
			sam.description,
			sam.biosample_status,
			sam.biosample_status_ontology,
			sam.biosample_status_ontology_label,
			sam.individual_age_at_collection,
			sam.obtention_procedure,
			sam.obtention_procedure_ontology,
			sam.obtention_procedure_ontology_label,
			sam.tumor_progression,
			sam.tumor_progression_ontology,
			sam.tumor_progression_ontology_label,
			sam.tumor_grade,
			sam.tumor_grade_ontology,
			sam.tumor_grade_ontology_label,
			sam.collection_date,
			sam.sample_origins
	ORDER BY sam.stable_id,
			ind.stable_id,
			sam.description,
			sam.biosample_status,
			sam.biosample_status_ontology,
			sam.individual_age_at_collection,
			sam.obtention_procedure,
			sam.obtention_procedure_ontology,
			sam.tumor_progression,
			sam.tumor_progression_ontology,
			sam.tumor_grade,
			sam.tumor_grade_ontology
			';
	
		-- Apply pagination
		_query = _query || '
		LIMIT $16 OFFSET $17';

	RAISE NOTICE '_query: %', _query;

	RETURN QUERY EXECUTE _query
	USING _variant_type, _start, _refseq, _reference_bases, _alternate_bases, 
		_reference_genome, _dataset_stable_ids, _end, _start_min, _start_max, _end_min, _end_max, 
		_biosample_stable_id, _individual_stable_id, _gvariant_id, _limit, _offset;
	-- #1=_variant_type, #2=_start, #3=_refseq, #4=_reference_bases, #5=_alternate_bases, 
	-- #6=_reference_genome, #7=_dataset_stable_ids, #8=_end, #9=_start_min, #10=_start_max, 
	-- #11=_end_min, #12=_end_max, 
	-- #13=_biosample_stable_id, #14=_individual_stable_id, #15=_gvariant_id
	-- #16=_limit, #17=_offset
END
$_$;


ALTER FUNCTION public.query_samples(_variant_type text, _start integer, _start_min integer, _start_max integer, _end integer, _end_min integer, _end_max integer, _refseq character varying, _reference_bases text, _alternate_bases text, _reference_genome text, _dataset_stable_ids text[], _is_authenticated boolean, _biosample_stable_id text, _individual_stable_id text, _gvariant_id integer, _filters text[], _offset integer, _limit integer, _requested_schemas text[]) OWNER TO microaccounts_dev;

--
-- TOC entry 253 (class 1255 OID 195985)
-- Name: test_hstore(); Type: FUNCTION; Schema: public; Owner: microaccounts_dev
--

CREATE FUNCTION public.test_hstore(OUT _value integer, OUT _hstore addons.hstore) RETURNS record
    LANGUAGE sql
    AS $$

SELECT 1, 'a=>1,b=>2'::addons.hstore;

$$;


ALTER FUNCTION public.test_hstore(OUT _value integer, OUT _hstore addons.hstore) OWNER TO microaccounts_dev;

SET default_tablespace = '';

--
-- TOC entry 187 (class 1259 OID 195986)
-- Name: consent_code_category_table; Type: TABLE; Schema: public; Owner: microaccounts_dev
--

CREATE TABLE public.consent_code_category_table (
    id integer NOT NULL,
    name character varying(11)
);


ALTER TABLE public.consent_code_category_table OWNER TO microaccounts_dev;

--
-- TOC entry 188 (class 1259 OID 195989)
-- Name: consent_code_table; Type: TABLE; Schema: public; Owner: microaccounts_dev
--

CREATE TABLE public.consent_code_table (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    abbr character varying(20) NOT NULL,
    description character varying(400) NOT NULL,
    additional_constraint_required boolean NOT NULL,
    category_id integer NOT NULL
);


ALTER TABLE public.consent_code_table OWNER TO microaccounts_dev;

--
-- TOC entry 189 (class 1259 OID 195995)
-- Name: consent_code_table_id_seq; Type: SEQUENCE; Schema: public; Owner: microaccounts_dev
--

CREATE SEQUENCE public.consent_code_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.consent_code_table_id_seq OWNER TO microaccounts_dev;

--
-- TOC entry 2560 (class 0 OID 0)
-- Dependencies: 189
-- Name: consent_code_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: microaccounts_dev
--

ALTER SEQUENCE public.consent_code_table_id_seq OWNED BY public.consent_code_table.id;


--
-- TOC entry 190 (class 1259 OID 195997)
-- Name: dataset_table; Type: TABLE; Schema: public; Owner: microaccounts_dev
--

CREATE TABLE public.dataset_table (
    id integer NOT NULL,
    stable_id character varying(50) NOT NULL,
    description character varying(800),
    access_type character varying(10),
    reference_genome character varying(50),
    variant_cnt bigint NOT NULL,
    call_cnt bigint,
    sample_cnt bigint NOT NULL,
    dataset_source text,
    dataset_type text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    name text,
    CONSTRAINT dataset_table_access_type_check CHECK (((access_type)::text = ANY (ARRAY['PUBLIC'::text, 'REGISTERED'::text, 'CONTROLLED'::text])))
);


ALTER TABLE public.dataset_table OWNER TO microaccounts_dev;

--
-- TOC entry 191 (class 1259 OID 196004)
-- Name: dataset; Type: VIEW; Schema: public; Owner: microaccounts_dev
--

CREATE VIEW public.dataset AS
 SELECT d.id,
    d.stable_id,
    d.name,
    d.description,
    d.access_type,
    d.reference_genome,
    d.variant_cnt,
    d.call_cnt,
    d.sample_cnt,
    d.dataset_source,
    d.dataset_type,
    d.created_at,
    d.updated_at
   FROM public.dataset_table d
  WHERE (((d.access_type)::text = ANY (ARRAY['PUBLIC'::text, 'REGISTERED'::text, 'CONTROLLED'::text])) AND (d.variant_cnt > 0) AND ((d.reference_genome)::text <> ''::text));


ALTER TABLE public.dataset OWNER TO microaccounts_dev;

--
-- TOC entry 192 (class 1259 OID 196008)
-- Name: dataset_access_level_table; Type: TABLE; Schema: public; Owner: microaccounts_dev
--

CREATE TABLE public.dataset_access_level_table (
    dataset_id integer NOT NULL,
    parent_field text NOT NULL,
    field text NOT NULL,
    access_level text NOT NULL,
    CONSTRAINT dataset_access_level_table_access_level_check CHECK ((access_level = ANY (ARRAY['NOT_SUPPORTED'::text, 'PUBLIC'::text, 'REGISTERED'::text, 'CONTROLLED'::text])))
);


ALTER TABLE public.dataset_access_level_table OWNER TO microaccounts_dev;

--
-- TOC entry 193 (class 1259 OID 196015)
-- Name: dataset_access_level; Type: VIEW; Schema: public; Owner: microaccounts_dev
--

CREATE VIEW public.dataset_access_level AS
 SELECT dat.stable_id AS dataset_stable_id,
    dal.parent_field,
    dal.field,
    dal.access_level
   FROM (public.dataset_access_level_table dal
     JOIN public.dataset_table dat ON ((dat.id = dal.dataset_id)));


ALTER TABLE public.dataset_access_level OWNER TO microaccounts_dev;

--
-- TOC entry 194 (class 1259 OID 196019)
-- Name: dataset_consent_code_table; Type: TABLE; Schema: public; Owner: microaccounts_dev
--

CREATE TABLE public.dataset_consent_code_table (
    dataset_id integer NOT NULL,
    consent_code_id integer NOT NULL,
    additional_constraint text,
    description text,
    version text
);


ALTER TABLE public.dataset_consent_code_table OWNER TO microaccounts_dev;

--
-- TOC entry 195 (class 1259 OID 196025)
-- Name: dataset_consent_code; Type: VIEW; Schema: public; Owner: microaccounts_dev
--

CREATE VIEW public.dataset_consent_code AS
 SELECT dc.dataset_id,
    cat.name AS category,
    code.abbr AS code,
    code.description,
    dc.additional_constraint,
    dc.description AS additional_description,
    dc.version
   FROM ((public.dataset_consent_code_table dc
     JOIN public.consent_code_table code ON ((code.id = dc.consent_code_id)))
     JOIN public.consent_code_category_table cat ON ((cat.id = code.category_id)))
  ORDER BY dc.dataset_id, cat.id, code.id;


ALTER TABLE public.dataset_consent_code OWNER TO microaccounts_dev;

--
-- TOC entry 196 (class 1259 OID 196029)
-- Name: dataset_sample_table; Type: TABLE; Schema: public; Owner: microaccounts_dev
--

CREATE TABLE public.dataset_sample_table (
    id integer NOT NULL,
    dataset_id integer NOT NULL,
    sample_id integer NOT NULL
);


ALTER TABLE public.dataset_sample_table OWNER TO microaccounts_dev;

--
-- TOC entry 197 (class 1259 OID 196032)
-- Name: dataset_sample_table_id_seq; Type: SEQUENCE; Schema: public; Owner: microaccounts_dev
--

CREATE SEQUENCE public.dataset_sample_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dataset_sample_table_id_seq OWNER TO microaccounts_dev;

--
-- TOC entry 2561 (class 0 OID 0)
-- Dependencies: 197
-- Name: dataset_sample_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: microaccounts_dev
--

ALTER SEQUENCE public.dataset_sample_table_id_seq OWNED BY public.dataset_sample_table.id;


--
-- TOC entry 198 (class 1259 OID 196034)
-- Name: dataset_table_id_seq; Type: SEQUENCE; Schema: public; Owner: microaccounts_dev
--

CREATE SEQUENCE public.dataset_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dataset_table_id_seq OWNER TO microaccounts_dev;

--
-- TOC entry 2562 (class 0 OID 0)
-- Dependencies: 198
-- Name: dataset_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: microaccounts_dev
--

ALTER SEQUENCE public.dataset_table_id_seq OWNED BY public.dataset_table.id;


--
-- TOC entry 199 (class 1259 OID 196036)
-- Name: individual_table; Type: TABLE; Schema: public; Owner: microaccounts_dev
--

CREATE TABLE public.individual_table (
    id integer NOT NULL,
    stable_id text,
    sex text NOT NULL,
    ethnicity text,
    geographic_origin text,
    taxon_id text,
    CONSTRAINT sex_constraint CHECK ((lower(sex) = ANY (ARRAY['female'::text, 'male'::text, 'other'::text, 'unknown'::text])))
);


ALTER TABLE public.individual_table OWNER TO microaccounts_dev;

--
-- TOC entry 200 (class 1259 OID 196043)
-- Name: individual; Type: VIEW; Schema: public; Owner: microaccounts_dev
--

CREATE VIEW public.individual AS
 SELECT individual_table.id,
    individual_table.stable_id,
    individual_table.sex,
    individual_table.ethnicity,
    individual_table.geographic_origin,
    individual_table.taxon_id
   FROM public.individual_table;


ALTER TABLE public.individual OWNER TO microaccounts_dev;

--
-- TOC entry 201 (class 1259 OID 196047)
-- Name: individual_disease_table; Type: TABLE; Schema: public; Owner: microaccounts_dev
--

CREATE TABLE public.individual_disease_table (
    id integer NOT NULL,
    individual_id integer NOT NULL,
    disease_id text NOT NULL,
    age text,
    age_group text,
    stage text,
    family_history boolean,
    date_of_onset date,
    onset_type text,
    severity text
);


ALTER TABLE public.individual_disease_table OWNER TO microaccounts_dev;

--
-- TOC entry 202 (class 1259 OID 196053)
-- Name: individual_disease_table_id_seq; Type: SEQUENCE; Schema: public; Owner: microaccounts_dev
--

CREATE SEQUENCE public.individual_disease_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.individual_disease_table_id_seq OWNER TO microaccounts_dev;

--
-- TOC entry 2563 (class 0 OID 0)
-- Dependencies: 202
-- Name: individual_disease_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: microaccounts_dev
--

ALTER SEQUENCE public.individual_disease_table_id_seq OWNED BY public.individual_disease_table.id;


--
-- TOC entry 226 (class 1259 OID 196488)
-- Name: ontology_table; Type: TABLE; Schema: public; Owner: microaccounts_dev
--

CREATE TABLE public.ontology_table (
    id integer NOT NULL,
    ontology_id text NOT NULL,
    ontology_name text NOT NULL,
    namespace_prefix text NOT NULL,
    url text NOT NULL,
    version text NOT NULL,
    iri_prefix text NOT NULL
);


ALTER TABLE public.ontology_table OWNER TO microaccounts_dev;

--
-- TOC entry 203 (class 1259 OID 196055)
-- Name: ontology_term_table; Type: TABLE; Schema: public; Owner: microaccounts_dev
--

CREATE TABLE public.ontology_term_table (
    id integer NOT NULL,
    ontology text NOT NULL,
    term text NOT NULL,
    target_table text NOT NULL,
    column_name text NOT NULL,
    column_value text,
    additional_comments text,
    label text,
    target_table_alias text NOT NULL,
    operator text,
    column_type text,
    ontology_id integer NOT NULL
);


ALTER TABLE public.ontology_term_table OWNER TO microaccounts_dev;

--
-- TOC entry 228 (class 1259 OID 196632)
-- Name: individual_disease_w_ontology_terms; Type: VIEW; Schema: public; Owner: microaccounts_dev
--

CREATE VIEW public.individual_disease_w_ontology_terms AS
 SELECT ind_dis.id,
    ind_dis.individual_id,
    ind_dis.disease_id,
        CASE
            WHEN (ot_disease.id IS NOT NULL) THEN ((ot_disease.ontology || ':'::text) || ot_disease.term)
            ELSE NULL::text
        END AS disease_id_ontology,
        CASE
            WHEN (ot_disease.id IS NOT NULL) THEN ot_disease.label
            ELSE NULL::text
        END AS disease_id_ontology_label,
    disease_ontology.id AS disease_ontology_id,
    ind_dis.age,
    ind_dis.age_group,
        CASE
            WHEN (ot_age_group.id IS NOT NULL) THEN ((ot_age_group.ontology || ':'::text) || ot_age_group.term)
            ELSE NULL::text
        END AS age_group_ontology,
        CASE
            WHEN (ot_age_group.id IS NOT NULL) THEN ot_age_group.label
            ELSE NULL::text
        END AS age_group_ontology_label,
    age_group_ontology.id AS age_group_ontology_id,
    ind_dis.stage,
        CASE
            WHEN (ot_stage.id IS NOT NULL) THEN ((ot_stage.ontology || ':'::text) || ot_stage.term)
            ELSE NULL::text
        END AS stage_ontology,
        CASE
            WHEN (ot_stage.id IS NOT NULL) THEN ot_stage.label
            ELSE NULL::text
        END AS stage_ontology_label,
    stage_ontology.id AS stage_ontology_id,
    ind_dis.family_history,
    ind_dis.date_of_onset,
    ind_dis.onset_type,
        CASE
            WHEN (ot_onset_type.id IS NOT NULL) THEN ((ot_onset_type.ontology || ':'::text) || ot_onset_type.term)
            ELSE NULL::text
        END AS onset_type_ontology,
        CASE
            WHEN (ot_onset_type.id IS NOT NULL) THEN ot_onset_type.label
            ELSE NULL::text
        END AS onset_type_ontology_label,
    onset_type_ontology.id AS onset_type_ontology_id,
    ind_dis.severity,
        CASE
            WHEN (ot_sever.id IS NOT NULL) THEN ((ot_sever.ontology || ':'::text) || ot_sever.term)
            ELSE NULL::text
        END AS severity_ontology,
        CASE
            WHEN (ot_sever.id IS NOT NULL) THEN ((ot_sever.ontology || ':'::text) || ot_sever.term)
            ELSE NULL::text
        END AS severity_ontology_label
   FROM (((((((((public.individual_disease_table ind_dis
     LEFT JOIN public.ontology_term_table ot_disease ON (((ot_disease.target_table = 'public.individual_disease_table'::text) AND (ot_disease.column_name = 'disease_id'::text) AND (lower(ot_disease.column_value) = lower(ind_dis.disease_id)))))
     LEFT JOIN public.ontology_table disease_ontology ON ((disease_ontology.id = ot_disease.ontology_id)))
     LEFT JOIN public.ontology_term_table ot_age_group ON (((ot_age_group.target_table = 'public.individual_disease_table'::text) AND (ot_age_group.column_name = 'age_group'::text) AND (lower(ot_age_group.column_value) = lower(ind_dis.age_group)))))
     LEFT JOIN public.ontology_table age_group_ontology ON ((age_group_ontology.id = ot_age_group.ontology_id)))
     LEFT JOIN public.ontology_term_table ot_stage ON (((ot_stage.target_table = 'public.individual_disease_table'::text) AND (ot_stage.column_name = 'stage'::text) AND (lower(ot_stage.column_value) = lower(ind_dis.stage)))))
     LEFT JOIN public.ontology_table stage_ontology ON ((stage_ontology.id = ot_stage.ontology_id)))
     LEFT JOIN public.ontology_term_table ot_onset_type ON (((ot_onset_type.target_table = 'public.individual_disease_table'::text) AND (ot_onset_type.column_name = 'onset_type'::text) AND (lower(ot_onset_type.column_value) = lower(ind_dis.onset_type)))))
     LEFT JOIN public.ontology_table onset_type_ontology ON ((onset_type_ontology.id = ot_onset_type.ontology_id)))
     LEFT JOIN public.ontology_term_table ot_sever ON (((ot_sever.target_table = 'public.individual_disease_table'::text) AND (ot_sever.column_name = 'severity'::text) AND (lower(ot_sever.column_value) = lower(ind_dis.severity)))));


ALTER TABLE public.individual_disease_w_ontology_terms OWNER TO microaccounts_dev;

--
-- TOC entry 205 (class 1259 OID 196070)
-- Name: individual_pedigree_table; Type: TABLE; Schema: public; Owner: microaccounts_dev
--

CREATE TABLE public.individual_pedigree_table (
    individual_id integer NOT NULL,
    pedigree_id integer NOT NULL,
    pedigree_role text NOT NULL,
    number_of_individuals_tested integer,
    disease_id text,
    affected_status text
);


ALTER TABLE public.individual_pedigree_table OWNER TO microaccounts_dev;

--
-- TOC entry 206 (class 1259 OID 196076)
-- Name: pedigree_table; Type: TABLE; Schema: public; Owner: microaccounts_dev
--

CREATE TABLE public.pedigree_table (
    id integer NOT NULL,
    stable_id text NOT NULL,
    description text
);


ALTER TABLE public.pedigree_table OWNER TO microaccounts_dev;

--
-- TOC entry 230 (class 1259 OID 196644)
-- Name: individual_pedigree_w_ontology_terms; Type: VIEW; Schema: public; Owner: microaccounts_dev
--

CREATE VIEW public.individual_pedigree_w_ontology_terms AS
 SELECT ind_ped.individual_id,
    ped.stable_id AS pedigree_stable_id,
    ind_ped.disease_id,
        CASE
            WHEN (ot_disease.id IS NOT NULL) THEN ((ot_disease.ontology || ':'::text) || ot_disease.term)
            ELSE NULL::text
        END AS disease_id_ontology,
        CASE
            WHEN (ot_disease.id IS NOT NULL) THEN ot_disease.label
            ELSE NULL::text
        END AS disease_id_ontology_label,
    ind_ped.pedigree_role,
        CASE
            WHEN (ot_role.id IS NOT NULL) THEN ((ot_role.ontology || ':'::text) || ot_role.term)
            ELSE NULL::text
        END AS pedigree_role_ontology,
        CASE
            WHEN (ot_role.id IS NOT NULL) THEN ot_role.label
            ELSE NULL::text
        END AS pedigree_role_ontology_label,
    ind_ped.affected_status,
    ind_ped.number_of_individuals_tested
   FROM (((public.individual_pedigree_table ind_ped
     JOIN public.pedigree_table ped ON ((ped.id = ind_ped.pedigree_id)))
     LEFT JOIN public.ontology_term_table ot_role ON (((ot_role.target_table = 'public.individual_pedigree_table'::text) AND (ot_role.column_name = 'pedigree_role'::text) AND (lower(ot_role.column_value) = lower(ind_ped.pedigree_role)))))
     LEFT JOIN public.ontology_term_table ot_disease ON (((ot_disease.target_table = 'public.individual_pedigree_table'::text) AND (ot_disease.column_name = 'disease_id'::text) AND (lower(ot_disease.column_value) = lower(ind_ped.disease_id)))));


ALTER TABLE public.individual_pedigree_w_ontology_terms OWNER TO microaccounts_dev;

--
-- TOC entry 207 (class 1259 OID 196087)
-- Name: individual_phenotypic_feature_table; Type: TABLE; Schema: public; Owner: psql_root
--

CREATE TABLE public.individual_phenotypic_feature_table (
    id integer NOT NULL,
    individual_id integer NOT NULL,
    phenotype_id text NOT NULL,
    date_of_onset date,
    onset_type text,
    age text,
    age_group text,
    severity text
);



--
-- TOC entry 208 (class 1259 OID 196093)
-- Name: individual_phenotypic_feature_table_id_seq; Type: SEQUENCE; Schema: public; Owner: psql_root
--

CREATE SEQUENCE public.individual_phenotypic_feature_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;



--
-- TOC entry 2565 (class 0 OID 0)
-- Dependencies: 208
-- Name: individual_phenotypic_feature_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: psql_root
--

ALTER SEQUENCE public.individual_phenotypic_feature_table_id_seq OWNED BY public.individual_phenotypic_feature_table.id;


--
-- TOC entry 229 (class 1259 OID 196637)
-- Name: individual_phenotypic_feature_w_ontology_terms; Type: VIEW; Schema: public; Owner: microaccounts_dev
--

CREATE VIEW public.individual_phenotypic_feature_w_ontology_terms AS
 SELECT ind_phf.id,
    ind_phf.individual_id,
    ind_phf.phenotype_id,
        CASE
            WHEN (ot_phenotype.id IS NOT NULL) THEN ((ot_phenotype.ontology || ':'::text) || ot_phenotype.term)
            ELSE NULL::text
        END AS phenotype_id_ontology,
        CASE
            WHEN (ot_phenotype.id IS NOT NULL) THEN ot_phenotype.label
            ELSE NULL::text
        END AS phenotype_id_ontology_label,
    phenotype_ontology.id AS phenotype_ontology_id,
    ind_phf.date_of_onset,
    ind_phf.onset_type,
        CASE
            WHEN (ot_onset_type.id IS NOT NULL) THEN ((ot_onset_type.ontology || ':'::text) || ot_onset_type.term)
            ELSE NULL::text
        END AS onset_type_ontology,
        CASE
            WHEN (ot_onset_type.id IS NOT NULL) THEN ot_onset_type.label
            ELSE NULL::text
        END AS onset_type_ontology_label,
    onset_type_ontology.id AS onset_type_ontology_id,
    ind_phf.age,
    ind_phf.age_group,
        CASE
            WHEN (ot_age_group.id IS NOT NULL) THEN ((ot_age_group.ontology || ':'::text) || ot_age_group.term)
            ELSE NULL::text
        END AS age_group_ontology,
        CASE
            WHEN (ot_age_group.id IS NOT NULL) THEN ot_age_group.label
            ELSE NULL::text
        END AS age_group_ontology_label,
    age_group_ontology.id AS age_group_ontology_id,
    ind_phf.severity,
        CASE
            WHEN (ot_severity.id IS NOT NULL) THEN ((ot_severity.ontology || ':'::text) || ot_severity.term)
            ELSE NULL::text
        END AS severity_ontology,
        CASE
            WHEN (ot_severity.id IS NOT NULL) THEN ot_severity.label
            ELSE NULL::text
        END AS severity_ontology_label,
    severity_ontology.id AS severity_ontology_id
   FROM ((((((((public.individual_phenotypic_feature_table ind_phf
     LEFT JOIN public.ontology_term_table ot_phenotype ON (((ot_phenotype.target_table = 'public.individual_phenotypic_feature_table'::text) AND (ot_phenotype.column_name = 'phenotype_id'::text) AND (lower(ot_phenotype.column_value) = lower(ind_phf.phenotype_id)))))
     LEFT JOIN public.ontology_table phenotype_ontology ON ((phenotype_ontology.id = ot_phenotype.ontology_id)))
     LEFT JOIN public.ontology_term_table ot_onset_type ON (((ot_onset_type.target_table = 'public.individual_phenotypic_feature_table'::text) AND (ot_onset_type.column_name = 'onset_type'::text) AND (lower(ot_onset_type.column_value) = lower(ind_phf.onset_type)))))
     LEFT JOIN public.ontology_table onset_type_ontology ON ((onset_type_ontology.id = ot_onset_type.ontology_id)))
     LEFT JOIN public.ontology_term_table ot_age_group ON (((ot_age_group.target_table = 'public.individual_phenotypic_feature_table'::text) AND (ot_age_group.column_name = 'age_group'::text) AND (lower(ot_age_group.column_value) = lower(ind_phf.age_group)))))
     LEFT JOIN public.ontology_table age_group_ontology ON ((age_group_ontology.id = ot_age_group.ontology_id)))
     LEFT JOIN public.ontology_term_table ot_severity ON (((ot_severity.target_table = 'public.individual_phenotypic_feature_table'::text) AND (ot_severity.column_name = 'severity'::text) AND (lower(ot_severity.column_value) = lower(ind_phf.severity)))))
     LEFT JOIN public.ontology_table severity_ontology ON ((severity_ontology.id = ot_severity.ontology_id)));


ALTER TABLE public.individual_phenotypic_feature_w_ontology_terms OWNER TO microaccounts_dev;

--
-- TOC entry 209 (class 1259 OID 196100)
-- Name: individual_table_id_seq; Type: SEQUENCE; Schema: public; Owner: microaccounts_dev
--

CREATE SEQUENCE public.individual_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.individual_table_id_seq OWNER TO microaccounts_dev;

--
-- TOC entry 2567 (class 0 OID 0)
-- Dependencies: 209
-- Name: individual_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: microaccounts_dev
--

ALTER SEQUENCE public.individual_table_id_seq OWNED BY public.individual_table.id;


--
-- TOC entry 227 (class 1259 OID 196627)
-- Name: individual_w_ontology_terms; Type: VIEW; Schema: public; Owner: microaccounts_dev
--

CREATE VIEW public.individual_w_ontology_terms AS
 SELECT ind.id,
    ind.stable_id,
    ind.taxon_id,
        CASE
            WHEN (ot_taxon.id IS NOT NULL) THEN ((ot_taxon.ontology || ':'::text) || ot_taxon.term)
            ELSE NULL::text
        END AS taxon_id_ontology,
        CASE
            WHEN (ot_taxon.id IS NOT NULL) THEN ot_taxon.label
            ELSE NULL::text
        END AS taxon_id_ontology_label,
    taxon_ontology.id AS taxon_ontology_id,
    ind.sex,
        CASE
            WHEN (ot_sex.id IS NOT NULL) THEN ((ot_sex.ontology || ':'::text) || ot_sex.term)
            ELSE NULL::text
        END AS sex_ontology,
        CASE
            WHEN (ot_sex.id IS NOT NULL) THEN ot_sex.label
            ELSE NULL::text
        END AS sex_ontology_label,
    sex_ontology.id AS sex_ontology_id,
    ind.ethnicity,
        CASE
            WHEN (ot_ethnicity.id IS NOT NULL) THEN ((ot_ethnicity.ontology || ':'::text) || ot_ethnicity.term)
            ELSE NULL::text
        END AS ethnicity_ontology,
        CASE
            WHEN (ot_ethnicity.id IS NOT NULL) THEN ot_ethnicity.label
            ELSE NULL::text
        END AS ethnicity_ontology_label,
    ind.geographic_origin,
        CASE
            WHEN (ot_geo_origin.id IS NOT NULL) THEN ((ot_geo_origin.ontology || ':'::text) || ot_geo_origin.term)
            ELSE NULL::text
        END AS geographic_origin_ontology,
        CASE
            WHEN (ot_geo_origin.id IS NOT NULL) THEN ot_geo_origin.label
            ELSE NULL::text
        END AS geographic_origin_ontology_label
   FROM ((((((public.individual_table ind
     LEFT JOIN public.ontology_term_table ot_taxon ON (((ot_taxon.target_table = 'public.individual_table'::text) AND (ot_taxon.column_name = 'taxon_id'::text) AND (lower(ot_taxon.column_value) = lower(ind.taxon_id)))))
     LEFT JOIN public.ontology_table taxon_ontology ON ((taxon_ontology.id = ot_taxon.ontology_id)))
     LEFT JOIN public.ontology_term_table ot_sex ON (((ot_sex.target_table = 'public.individual_table'::text) AND (ot_sex.column_name = 'sex'::text) AND (lower(ot_sex.column_value) = lower(ind.sex)))))
     LEFT JOIN public.ontology_table sex_ontology ON ((sex_ontology.id = ot_sex.ontology_id)))
     LEFT JOIN public.ontology_term_table ot_ethnicity ON (((ot_ethnicity.target_table = 'public.individual_table'::text) AND (ot_ethnicity.column_name = 'ethnicity'::text) AND (lower(ot_ethnicity.column_value) = lower(ind.ethnicity)))))
     LEFT JOIN public.ontology_term_table ot_geo_origin ON (((ot_geo_origin.target_table = 'public.individual_table'::text) AND (ot_geo_origin.column_name = 'geographic_origin'::text) AND (lower(ot_geo_origin.column_value) = lower(ind.geographic_origin)))));


ALTER TABLE public.individual_w_ontology_terms OWNER TO microaccounts_dev;

--
-- TOC entry 225 (class 1259 OID 196486)
-- Name: ontology_table_id_seq; Type: SEQUENCE; Schema: public; Owner: microaccounts_dev
--

CREATE SEQUENCE public.ontology_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ontology_table_id_seq OWNER TO microaccounts_dev;

--
-- TOC entry 2568 (class 0 OID 0)
-- Dependencies: 225
-- Name: ontology_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: microaccounts_dev
--

ALTER SEQUENCE public.ontology_table_id_seq OWNED BY public.ontology_table.id;


--
-- TOC entry 204 (class 1259 OID 196061)
-- Name: ontology_term; Type: VIEW; Schema: public; Owner: microaccounts_dev
--

CREATE VIEW public.ontology_term AS
 SELECT ontology_term_table.id,
    ontology_term_table.ontology,
    ontology_term_table.term,
    ontology_term_table.target_table,
    ontology_term_table.column_name,
    ontology_term_table.column_value,
    ontology_term_table.additional_comments,
    ontology_term_table.label,
    ontology_term_table.target_table_alias
   FROM public.ontology_term_table;


ALTER TABLE public.ontology_term OWNER TO microaccounts_dev;

--
-- TOC entry 210 (class 1259 OID 196107)
-- Name: ontology_term_table_id_seq; Type: SEQUENCE; Schema: public; Owner: microaccounts_dev
--

CREATE SEQUENCE public.ontology_term_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ontology_term_table_id_seq OWNER TO microaccounts_dev;

--
-- TOC entry 2569 (class 0 OID 0)
-- Dependencies: 210
-- Name: ontology_term_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: microaccounts_dev
--

ALTER SEQUENCE public.ontology_term_table_id_seq OWNED BY public.ontology_term_table.id;


--
-- TOC entry 211 (class 1259 OID 196109)
-- Name: pedigree_table_id_seq; Type: SEQUENCE; Schema: public; Owner: microaccounts_dev
--

CREATE SEQUENCE public.pedigree_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pedigree_table_id_seq OWNER TO microaccounts_dev;

--
-- TOC entry 2570 (class 0 OID 0)
-- Dependencies: 211
-- Name: pedigree_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: microaccounts_dev
--

ALTER SEQUENCE public.pedigree_table_id_seq OWNED BY public.pedigree_table.id;


--
-- TOC entry 212 (class 1259 OID 196111)
-- Name: sample_table; Type: TABLE; Schema: public; Owner: microaccounts_dev
--

CREATE TABLE public.sample_table (
    id integer NOT NULL,
    stable_id text NOT NULL,
    individual_id integer,
    description text,
    biosample_status text,
    individual_age_at_collection text,
    obtention_procedure text,
    tumor_progression text,
    tumor_grade text,
    collection_date date,
    sample_origins jsonb
);


ALTER TABLE public.sample_table OWNER TO microaccounts_dev;

--
-- TOC entry 213 (class 1259 OID 196117)
-- Name: sample_table_id_seq; Type: SEQUENCE; Schema: public; Owner: microaccounts_dev
--

CREATE SEQUENCE public.sample_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sample_table_id_seq OWNER TO microaccounts_dev;

--
-- TOC entry 2571 (class 0 OID 0)
-- Dependencies: 213
-- Name: sample_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: microaccounts_dev
--

ALTER SEQUENCE public.sample_table_id_seq OWNED BY public.sample_table.id;


--
-- TOC entry 214 (class 1259 OID 196119)
-- Name: sample_w_ontology_terms; Type: VIEW; Schema: public; Owner: microaccounts_dev
--

CREATE VIEW public.sample_w_ontology_terms AS
 SELECT sam.id,
    sam.stable_id,
    sam.individual_id,
    sam.description,
    sam.biosample_status,
        CASE
            WHEN (ot_status.id IS NOT NULL) THEN ((ot_status.ontology || ':'::text) || ot_status.term)
            ELSE NULL::text
        END AS biosample_status_ontology,
        CASE
            WHEN (ot_status.id IS NOT NULL) THEN ot_status.label
            ELSE NULL::text
        END AS biosample_status_ontology_label,
    sam.individual_age_at_collection,
    sam.obtention_procedure,
        CASE
            WHEN (ot_proc.id IS NOT NULL) THEN ((ot_proc.ontology || ':'::text) || ot_proc.term)
            ELSE NULL::text
        END AS obtention_procedure_ontology,
        CASE
            WHEN (ot_proc.id IS NOT NULL) THEN ot_proc.label
            ELSE NULL::text
        END AS obtention_procedure_ontology_label,
    sam.tumor_progression,
        CASE
            WHEN (ot_t_progress.id IS NOT NULL) THEN ((ot_t_progress.ontology || ':'::text) || ot_t_progress.term)
            ELSE NULL::text
        END AS tumor_progression_ontology,
        CASE
            WHEN (ot_t_progress.id IS NOT NULL) THEN ot_t_progress.label
            ELSE NULL::text
        END AS tumor_progression_ontology_label,
    sam.tumor_grade,
        CASE
            WHEN (ot_t_grade.id IS NOT NULL) THEN ((ot_t_grade.ontology || ':'::text) || ot_t_grade.term)
            ELSE NULL::text
        END AS tumor_grade_ontology,
        CASE
            WHEN (ot_t_grade.id IS NOT NULL) THEN ot_t_grade.label
            ELSE NULL::text
        END AS tumor_grade_ontology_label,
    sam.collection_date,
    sam.sample_origins
   FROM ((((public.sample_table sam
     LEFT JOIN public.ontology_term ot_status ON (((ot_status.target_table = 'public.sample_table'::text) AND (ot_status.column_name = 'biosample_status'::text) AND (lower(ot_status.column_value) = lower(sam.biosample_status)))))
     LEFT JOIN public.ontology_term ot_proc ON (((ot_proc.target_table = 'public.sample_table'::text) AND (ot_proc.column_name = 'obtention_procedure'::text) AND (lower(ot_proc.column_value) = lower(sam.obtention_procedure)))))
     LEFT JOIN public.ontology_term ot_t_progress ON (((ot_t_progress.target_table = 'public.sample_table'::text) AND (ot_t_progress.column_name = 'tumor_progression'::text) AND (lower(ot_t_progress.column_value) = lower(sam.tumor_progression)))))
     LEFT JOIN public.ontology_term ot_t_grade ON (((ot_t_grade.target_table = 'public.sample_table'::text) AND (ot_t_grade.column_name = 'tumor_grade'::text) AND (lower(ot_t_grade.column_value) = lower(sam.tumor_grade)))));


ALTER TABLE public.sample_w_ontology_terms OWNER TO microaccounts_dev;

--
-- TOC entry 232 (class 1259 OID 196724)
-- Name: schema_table; Type: TABLE; Schema: public; Owner: microaccounts_dev
--

CREATE TABLE public.schema_table (
    id integer NOT NULL,
    schema_name text NOT NULL,
    table_name text NOT NULL,
    field_name text NOT NULL,
    format text NOT NULL,
    is_default boolean DEFAULT false NOT NULL
);


ALTER TABLE public.schema_table OWNER TO microaccounts_dev;

--
-- TOC entry 231 (class 1259 OID 196722)
-- Name: schema_table_id_seq; Type: SEQUENCE; Schema: public; Owner: microaccounts_dev
--

CREATE SEQUENCE public.schema_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.schema_table_id_seq OWNER TO microaccounts_dev;

--
-- TOC entry 2572 (class 0 OID 0)
-- Dependencies: 231
-- Name: schema_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: microaccounts_dev
--

ALTER SEQUENCE public.schema_table_id_seq OWNED BY public.schema_table.id;


--
-- TOC entry 215 (class 1259 OID 196133)
-- Name: tmp_sample_table; Type: TABLE; Schema: public; Owner: microaccounts_dev
--

CREATE TABLE public.tmp_sample_table (
    id integer NOT NULL,
    sample_stable_id text NOT NULL,
    dataset_id integer NOT NULL
);


ALTER TABLE public.tmp_sample_table OWNER TO microaccounts_dev;

--
-- TOC entry 216 (class 1259 OID 196139)
-- Name: tmp_sample_table_id_seq; Type: SEQUENCE; Schema: public; Owner: microaccounts_dev
--

CREATE SEQUENCE public.tmp_sample_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tmp_sample_table_id_seq OWNER TO microaccounts_dev;

--
-- TOC entry 2573 (class 0 OID 0)
-- Dependencies: 216
-- Name: tmp_sample_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: microaccounts_dev
--

ALTER SEQUENCE public.tmp_sample_table_id_seq OWNED BY public.tmp_sample_table.id;


--
-- TOC entry 217 (class 1259 OID 196149)
-- Name: tmp_variant_table; Type: TABLE; Schema: public; Owner: microaccounts_dev
--

CREATE TABLE public.tmp_variant_table (
    id integer NOT NULL,
    dataset_id integer NOT NULL,
    chromosome character varying(2) NOT NULL,
    variant_id text,
    reference text NOT NULL,
    alternate text NOT NULL,
    start integer NOT NULL,
    "end" integer,
    type character varying(10),
    sv_length integer,
    variant_cnt integer,
    call_cnt integer,
    sample_cnt integer,
    matching_sample_cnt integer,
    frequency numeric,
    genomic_hgvs_id text,
    transcript_hgvs_ids text[],
    protein_hgvs_ids text[],
    genomic_regions text[],
    molecular_effects text[],
    aminoacid_changes text[],
    effect_impacts text[],
    functional_classes text[],
    codon_changes text[],
    aminoacid_lengths text[],
    gene_names text[],
    transcript_biotypes text[],
    gene_codings text[],
    transcript_ids text[],
    exon_ranks text[],
    genotypes text[],
    custom_id bigint NOT NULL
);


ALTER TABLE public.tmp_variant_table OWNER TO microaccounts_dev;

--
-- TOC entry 222 (class 1259 OID 196330)
-- Name: tmp_variant_annot_without_duplicates; Type: VIEW; Schema: public; Owner: microaccounts_dev
--

CREATE VIEW public.tmp_variant_annot_without_duplicates AS
 SELECT tmp_variant_table.dataset_id,
    tmp_variant_table.chromosome,
    tmp_variant_table.variant_id,
    tmp_variant_table.reference,
    tmp_variant_table.alternate,
    tmp_variant_table.start,
    tmp_variant_table."end",
    tmp_variant_table.type,
    tmp_variant_table.sv_length,
    tmp_variant_table.variant_cnt,
    tmp_variant_table.call_cnt,
    tmp_variant_table.sample_cnt,
    tmp_variant_table.matching_sample_cnt,
    tmp_variant_table.frequency,
    tmp_variant_table.custom_id,
    ARRAY( SELECT q.v
           FROM ( SELECT t.v
                   FROM unnest(tmp_variant_table.molecular_effects) WITH ORDINALITY t(v, ord)
                  GROUP BY t.v
                  ORDER BY (min(t.ord))) q
          WHERE (q.v <> 'NA'::text)) AS molecular_effects,
    ARRAY( SELECT q.v
           FROM ( SELECT t.v
                   FROM unnest(tmp_variant_table.effect_impacts) WITH ORDINALITY t(v, ord)
                  GROUP BY t.v
                  ORDER BY (min(t.ord))) q
          WHERE (q.v <> 'NA'::text)) AS effect_impacts,
    ARRAY( SELECT q.v
           FROM ( SELECT t.v
                   FROM unnest(tmp_variant_table.functional_classes) WITH ORDINALITY t(v, ord)
                  GROUP BY t.v
                  ORDER BY (min(t.ord))) q
          WHERE (q.v <> 'NA'::text)) AS functional_classes,
    ARRAY( SELECT q.v
           FROM ( SELECT t.v
                   FROM unnest(tmp_variant_table.codon_changes) WITH ORDINALITY t(v, ord)
                  GROUP BY t.v
                  ORDER BY (min(t.ord))) q
          WHERE (q.v <> 'NA'::text)) AS codon_changes,
    ARRAY( SELECT q.v
           FROM ( SELECT t.v
                   FROM unnest(tmp_variant_table.aminoacid_changes) WITH ORDINALITY t(v, ord)
                  GROUP BY t.v
                  ORDER BY (min(t.ord))) q
          WHERE (q.v <> 'NA'::text)) AS aminoacid_changes,
    ARRAY( SELECT (q.v)::integer AS v
           FROM ( SELECT t.v
                   FROM unnest(tmp_variant_table.aminoacid_lengths) WITH ORDINALITY t(v, ord)
                  GROUP BY t.v
                  ORDER BY (min(t.ord))) q
          WHERE (q.v <> 'NA'::text)) AS aminoacid_lengths,
    ARRAY( SELECT q.v
           FROM ( SELECT t.v
                   FROM unnest(tmp_variant_table.gene_names) WITH ORDINALITY t(v, ord)
                  GROUP BY t.v
                  ORDER BY (min(t.ord))) q
          WHERE (q.v <> 'NA'::text)) AS gene_names,
    ARRAY( SELECT q.v
           FROM ( SELECT t.v
                   FROM unnest(tmp_variant_table.transcript_biotypes) WITH ORDINALITY t(v, ord)
                  GROUP BY t.v
                  ORDER BY (min(t.ord))) q
          WHERE (q.v <> 'NA'::text)) AS transcript_biotypes,
    ARRAY( SELECT q.v
           FROM ( SELECT t.v
                   FROM unnest(tmp_variant_table.gene_codings) WITH ORDINALITY t(v, ord)
                  GROUP BY t.v
                  ORDER BY (min(t.ord))) q
          WHERE (q.v <> 'NA'::text)) AS gene_codings,
    ARRAY( SELECT q.v
           FROM ( SELECT t.v
                   FROM unnest(tmp_variant_table.transcript_ids) WITH ORDINALITY t(v, ord)
                  GROUP BY t.v
                  ORDER BY (min(t.ord))) q
          WHERE (q.v <> 'NA'::text)) AS transcript_ids,
    ARRAY( SELECT q.v
           FROM ( SELECT t.v
                   FROM unnest(tmp_variant_table.exon_ranks) WITH ORDINALITY t(v, ord)
                  GROUP BY t.v
                  ORDER BY (min(t.ord))) q
          WHERE (q.v <> 'NA'::text)) AS exon_ranks,
    ARRAY( SELECT q.v
           FROM ( SELECT t.v
                   FROM unnest(tmp_variant_table.genotypes) WITH ORDINALITY t(v, ord)
                  GROUP BY t.v
                  ORDER BY (min(t.ord))) q
          WHERE (q.v <> 'NA'::text)) AS genotypes
   FROM public.tmp_variant_table;


ALTER TABLE public.tmp_variant_annot_without_duplicates OWNER TO microaccounts_dev;

--
-- TOC entry 224 (class 1259 OID 196384)
-- Name: tmp_variant_sample_table; Type: TABLE; Schema: public; Owner: microaccounts_dev
--

CREATE TABLE public.tmp_variant_sample_table (
    id integer NOT NULL,
    dataset_id integer NOT NULL,
    sample_ids text[] NOT NULL,
    custom_id integer NOT NULL
);


ALTER TABLE public.tmp_variant_sample_table OWNER TO microaccounts_dev;

--
-- TOC entry 223 (class 1259 OID 196382)
-- Name: tmp_variant_sample_table_id_seq; Type: SEQUENCE; Schema: public; Owner: microaccounts_dev
--

CREATE SEQUENCE public.tmp_variant_sample_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tmp_variant_sample_table_id_seq OWNER TO microaccounts_dev;

--
-- TOC entry 2574 (class 0 OID 0)
-- Dependencies: 223
-- Name: tmp_variant_sample_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: microaccounts_dev
--

ALTER SEQUENCE public.tmp_variant_sample_table_id_seq OWNED BY public.tmp_variant_sample_table.id;


--
-- TOC entry 218 (class 1259 OID 196155)
-- Name: tmp_variant_table_id_seq; Type: SEQUENCE; Schema: public; Owner: microaccounts_dev
--

CREATE SEQUENCE public.tmp_variant_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tmp_variant_table_id_seq OWNER TO microaccounts_dev;

--
-- TOC entry 2575 (class 0 OID 0)
-- Dependencies: 218
-- Name: tmp_variant_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: microaccounts_dev
--

ALTER SEQUENCE public.tmp_variant_table_id_seq OWNED BY public.tmp_variant_table.id;


--
-- TOC entry 219 (class 1259 OID 196157)
-- Name: variant_sample_table; Type: TABLE; Schema: public; Owner: microaccounts_dev
--

CREATE TABLE public.variant_sample_table (
    variant_id integer NOT NULL,
    sample_id integer NOT NULL,
    frequency numeric,
    zygosity text,
    allele_origin text
);


ALTER TABLE public.variant_sample_table OWNER TO microaccounts_dev;

--
-- TOC entry 220 (class 1259 OID 196163)
-- Name: variant_table; Type: TABLE; Schema: public; Owner: microaccounts_dev
--

CREATE TABLE public.variant_table (
    id integer NOT NULL,
    dataset_id integer NOT NULL,
    refseq character varying(2) NOT NULL,
    variant_id text,
    reference text NOT NULL,
    alternate text NOT NULL,
    start integer NOT NULL,
    "end" integer,
    type character varying(10),
    sv_length integer,
    variant_cnt integer,
    call_cnt integer,
    sample_cnt integer,
    matching_sample_cnt integer,
    frequency numeric,
    genomic_hgvs_id text,
    transcript_hgvs_ids text[],
    protein_hgvs_ids text[],
    genomic_regions text[],
    molecular_effects text[],
    aminoacid_changes text[],
    effect_impacts text[],
    functional_classes text[],
    codon_changes text[],
    aminoacid_lengths text[],
    gene_names text[],
    transcript_biotypes text[],
    gene_codings text[],
    transcript_ids text[],
    exon_ranks text[],
    genotypes text[],
    custom_id bigint
);


ALTER TABLE public.variant_table OWNER TO microaccounts_dev;

--
-- TOC entry 221 (class 1259 OID 196169)
-- Name: variant_table_id_seq; Type: SEQUENCE; Schema: public; Owner: microaccounts_dev
--

CREATE SEQUENCE public.variant_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.variant_table_id_seq OWNER TO microaccounts_dev;

--
-- TOC entry 2576 (class 0 OID 0)
-- Dependencies: 221
-- Name: variant_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: microaccounts_dev
--

ALTER SEQUENCE public.variant_table_id_seq OWNED BY public.variant_table.id;


--
-- TOC entry 2276 (class 2604 OID 196171)
-- Name: consent_code_table id; Type: DEFAULT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.consent_code_table ALTER COLUMN id SET DEFAULT nextval('public.consent_code_table_id_seq'::regclass);


--
-- TOC entry 2280 (class 2604 OID 196172)
-- Name: dataset_sample_table id; Type: DEFAULT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.dataset_sample_table ALTER COLUMN id SET DEFAULT nextval('public.dataset_sample_table_id_seq'::regclass);


--
-- TOC entry 2277 (class 2604 OID 196173)
-- Name: dataset_table id; Type: DEFAULT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.dataset_table ALTER COLUMN id SET DEFAULT nextval('public.dataset_table_id_seq'::regclass);


--
-- TOC entry 2283 (class 2604 OID 196174)
-- Name: individual_disease_table id; Type: DEFAULT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.individual_disease_table ALTER COLUMN id SET DEFAULT nextval('public.individual_disease_table_id_seq'::regclass);


--
-- TOC entry 2286 (class 2604 OID 196175)
-- Name: individual_phenotypic_feature_table id; Type: DEFAULT; Schema: public; Owner: psql_root
--

ALTER TABLE ONLY public.individual_phenotypic_feature_table ALTER COLUMN id SET DEFAULT nextval('public.individual_phenotypic_feature_table_id_seq'::regclass);


--
-- TOC entry 2281 (class 2604 OID 196176)
-- Name: individual_table id; Type: DEFAULT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.individual_table ALTER COLUMN id SET DEFAULT nextval('public.individual_table_id_seq'::regclass);


--
-- TOC entry 2292 (class 2604 OID 196491)
-- Name: ontology_table id; Type: DEFAULT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.ontology_table ALTER COLUMN id SET DEFAULT nextval('public.ontology_table_id_seq'::regclass);


--
-- TOC entry 2284 (class 2604 OID 196177)
-- Name: ontology_term_table id; Type: DEFAULT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.ontology_term_table ALTER COLUMN id SET DEFAULT nextval('public.ontology_term_table_id_seq'::regclass);


--
-- TOC entry 2285 (class 2604 OID 196178)
-- Name: pedigree_table id; Type: DEFAULT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.pedigree_table ALTER COLUMN id SET DEFAULT nextval('public.pedigree_table_id_seq'::regclass);


--
-- TOC entry 2287 (class 2604 OID 196179)
-- Name: sample_table id; Type: DEFAULT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.sample_table ALTER COLUMN id SET DEFAULT nextval('public.sample_table_id_seq'::regclass);


--
-- TOC entry 2293 (class 2604 OID 196727)
-- Name: schema_table id; Type: DEFAULT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.schema_table ALTER COLUMN id SET DEFAULT nextval('public.schema_table_id_seq'::regclass);


--
-- TOC entry 2288 (class 2604 OID 196181)
-- Name: tmp_sample_table id; Type: DEFAULT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.tmp_sample_table ALTER COLUMN id SET DEFAULT nextval('public.tmp_sample_table_id_seq'::regclass);


--
-- TOC entry 2291 (class 2604 OID 196387)
-- Name: tmp_variant_sample_table id; Type: DEFAULT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.tmp_variant_sample_table ALTER COLUMN id SET DEFAULT nextval('public.tmp_variant_sample_table_id_seq'::regclass);


--
-- TOC entry 2289 (class 2604 OID 196183)
-- Name: tmp_variant_table id; Type: DEFAULT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.tmp_variant_table ALTER COLUMN id SET DEFAULT nextval('public.tmp_variant_table_id_seq'::regclass);


--
-- TOC entry 2290 (class 2604 OID 196184)
-- Name: variant_table id; Type: DEFAULT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.variant_table ALTER COLUMN id SET DEFAULT nextval('public.variant_table_id_seq'::regclass);


--
-- TOC entry 2336 (class 2606 OID 196186)
-- Name: variant_sample_table beacon_data_sample_table_pkey; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.variant_sample_table
    ADD CONSTRAINT beacon_data_sample_table_pkey PRIMARY KEY (variant_id, sample_id);


--
-- TOC entry 2342 (class 2606 OID 196188)
-- Name: variant_table beacon_data_table_pkey; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.variant_table
    ADD CONSTRAINT beacon_data_table_pkey PRIMARY KEY (id);


--
-- TOC entry 2328 (class 2606 OID 196190)
-- Name: sample_table beacon_sample_table_pkey; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.sample_table
    ADD CONSTRAINT beacon_sample_table_pkey PRIMARY KEY (id);


--
-- TOC entry 2296 (class 2606 OID 196192)
-- Name: consent_code_category_table consent_code_category_table_pkey; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.consent_code_category_table
    ADD CONSTRAINT consent_code_category_table_pkey PRIMARY KEY (id);


--
-- TOC entry 2298 (class 2606 OID 196194)
-- Name: consent_code_table consent_code_table_pkey; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.consent_code_table
    ADD CONSTRAINT consent_code_table_pkey PRIMARY KEY (id);


--
-- TOC entry 2304 (class 2606 OID 196196)
-- Name: dataset_access_level_table dataset_access_level_table_pkey; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.dataset_access_level_table
    ADD CONSTRAINT dataset_access_level_table_pkey PRIMARY KEY (dataset_id, parent_field, field);


--
-- TOC entry 2306 (class 2606 OID 196198)
-- Name: dataset_consent_code_table dataset_consent_code_table_pkey; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.dataset_consent_code_table
    ADD CONSTRAINT dataset_consent_code_table_pkey PRIMARY KEY (dataset_id, consent_code_id);


--
-- TOC entry 2308 (class 2606 OID 196200)
-- Name: dataset_sample_table dataset_sample_table_dataset_id_sample_id_key; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.dataset_sample_table
    ADD CONSTRAINT dataset_sample_table_dataset_id_sample_id_key UNIQUE (dataset_id, sample_id);


--
-- TOC entry 2310 (class 2606 OID 196202)
-- Name: dataset_sample_table dataset_sample_table_pkey; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.dataset_sample_table
    ADD CONSTRAINT dataset_sample_table_pkey PRIMARY KEY (id);


--
-- TOC entry 2300 (class 2606 OID 196204)
-- Name: dataset_table dataset_table_pkey; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.dataset_table
    ADD CONSTRAINT dataset_table_pkey PRIMARY KEY (id);


--
-- TOC entry 2326 (class 2606 OID 196206)
-- Name: individual_phenotypic_feature_table individual_phenotypic_feature_table_pkey; Type: CONSTRAINT; Schema: public; Owner: psql_root
--

ALTER TABLE ONLY public.individual_phenotypic_feature_table
    ADD CONSTRAINT individual_phenotypic_feature_table_pkey PRIMARY KEY (id);


--
-- TOC entry 2348 (class 2606 OID 196496)
-- Name: ontology_table ontology_table_pkey; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.ontology_table
    ADD CONSTRAINT ontology_table_pkey PRIMARY KEY (id);


--
-- TOC entry 2316 (class 2606 OID 196208)
-- Name: ontology_term_table ontology_term_table_ontology_term_target_table_column_name_key; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.ontology_term_table
    ADD CONSTRAINT ontology_term_table_ontology_term_target_table_column_name_key UNIQUE (ontology, term, target_table, column_name);


--
-- TOC entry 2318 (class 2606 OID 196394)
-- Name: ontology_term_table ontology_term_table_pkey; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.ontology_term_table
    ADD CONSTRAINT ontology_term_table_pkey PRIMARY KEY (id);


--
-- TOC entry 2314 (class 2606 OID 196210)
-- Name: individual_disease_table patient_disease_table_pkey; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.individual_disease_table
    ADD CONSTRAINT patient_disease_table_pkey PRIMARY KEY (id);


--
-- TOC entry 2320 (class 2606 OID 196212)
-- Name: individual_pedigree_table patient_pedigree_table_pkey; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.individual_pedigree_table
    ADD CONSTRAINT patient_pedigree_table_pkey PRIMARY KEY (individual_id, pedigree_id);


--
-- TOC entry 2312 (class 2606 OID 196214)
-- Name: individual_table patient_table_pkey; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.individual_table
    ADD CONSTRAINT patient_table_pkey PRIMARY KEY (id);


--
-- TOC entry 2322 (class 2606 OID 196216)
-- Name: pedigree_table pedigree_table_pkey; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.pedigree_table
    ADD CONSTRAINT pedigree_table_pkey PRIMARY KEY (id);


--
-- TOC entry 2324 (class 2606 OID 196218)
-- Name: pedigree_table pedigree_table_stable_id_key; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.pedigree_table
    ADD CONSTRAINT pedigree_table_stable_id_key UNIQUE (stable_id);


--
-- TOC entry 2331 (class 2606 OID 196220)
-- Name: sample_table sample_unique; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.sample_table
    ADD CONSTRAINT sample_unique UNIQUE (stable_id);


--
-- TOC entry 2350 (class 2606 OID 196733)
-- Name: schema_table schema_table_pkey; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.schema_table
    ADD CONSTRAINT schema_table_pkey PRIMARY KEY (id);


--
-- TOC entry 2352 (class 2606 OID 196735)
-- Name: schema_table schema_table_schema_name_table_name_field_name_is_default_key; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.schema_table
    ADD CONSTRAINT schema_table_schema_name_table_name_field_name_is_default_key UNIQUE (schema_name, table_name, field_name, is_default);


--
-- TOC entry 2346 (class 2606 OID 196392)
-- Name: tmp_variant_sample_table tmp_variant_sample_table_pkey; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.tmp_variant_sample_table
    ADD CONSTRAINT tmp_variant_sample_table_pkey PRIMARY KEY (id);


--
-- TOC entry 2334 (class 2606 OID 196228)
-- Name: tmp_variant_table tmp_variant_table_pkey; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.tmp_variant_table
    ADD CONSTRAINT tmp_variant_table_pkey PRIMARY KEY (id);


--
-- TOC entry 2302 (class 2606 OID 196230)
-- Name: dataset_table unique_dataset_stable_id_reference_genome_access_type; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.dataset_table
    ADD CONSTRAINT unique_dataset_stable_id_reference_genome_access_type UNIQUE (stable_id, access_type, reference_genome);


--
-- TOC entry 2340 (class 2606 OID 196232)
-- Name: variant_sample_table variant_sample_link_unique; Type: CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.variant_sample_table
    ADD CONSTRAINT variant_sample_link_unique UNIQUE (variant_id, sample_id);


--
-- TOC entry 2329 (class 1259 OID 196233)
-- Name: idx_sample_table_stable_id; Type: INDEX; Schema: public; Owner: microaccounts_dev
--

CREATE INDEX idx_sample_table_stable_id ON public.sample_table USING btree (stable_id);


--
-- TOC entry 2332 (class 1259 OID 196235)
-- Name: idx_tmp_variant_table_variant_columns; Type: INDEX; Schema: public; Owner: microaccounts_dev
--

CREATE INDEX idx_tmp_variant_table_variant_columns ON public.tmp_variant_table USING btree (dataset_id, chromosome, variant_id, reference, alternate, start, type);


--
-- TOC entry 2337 (class 1259 OID 196236)
-- Name: idx_variant_sample_table_data_id; Type: INDEX; Schema: public; Owner: microaccounts_dev
--

CREATE INDEX idx_variant_sample_table_data_id ON public.variant_sample_table USING btree (variant_id);


--
-- TOC entry 2338 (class 1259 OID 196237)
-- Name: idx_variant_sample_table_sample_id; Type: INDEX; Schema: public; Owner: microaccounts_dev
--

CREATE INDEX idx_variant_sample_table_sample_id ON public.variant_sample_table USING btree (sample_id);


--
-- TOC entry 2343 (class 1259 OID 196238)
-- Name: idx_variant_table_region_columns; Type: INDEX; Schema: public; Owner: microaccounts_dev
--

CREATE INDEX idx_variant_table_region_columns ON public.variant_table USING btree (dataset_id, refseq, start, "end");


--
-- TOC entry 2344 (class 1259 OID 196239)
-- Name: idx_variant_table_snp_columns; Type: INDEX; Schema: public; Owner: microaccounts_dev
--

CREATE INDEX idx_variant_table_snp_columns ON public.variant_table USING btree (dataset_id, refseq, reference, alternate, start);


--
-- TOC entry 2353 (class 2606 OID 196240)
-- Name: consent_code_table consent_code_table_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.consent_code_table
    ADD CONSTRAINT consent_code_table_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.consent_code_category_table(id);


--
-- TOC entry 2354 (class 2606 OID 196245)
-- Name: dataset_access_level_table dataset_access_level_table_dataset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.dataset_access_level_table
    ADD CONSTRAINT dataset_access_level_table_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES public.dataset_table(id);


--
-- TOC entry 2355 (class 2606 OID 196250)
-- Name: dataset_consent_code_table dataset_consent_code_table_consent_code_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.dataset_consent_code_table
    ADD CONSTRAINT dataset_consent_code_table_consent_code_id_fkey FOREIGN KEY (consent_code_id) REFERENCES public.consent_code_table(id);


--
-- TOC entry 2356 (class 2606 OID 196255)
-- Name: dataset_consent_code_table dataset_consent_code_table_dataset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.dataset_consent_code_table
    ADD CONSTRAINT dataset_consent_code_table_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES public.dataset_table(id);


--
-- TOC entry 2357 (class 2606 OID 196260)
-- Name: dataset_sample_table dataset_sample_table_dataset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.dataset_sample_table
    ADD CONSTRAINT dataset_sample_table_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES public.dataset_table(id);


--
-- TOC entry 2358 (class 2606 OID 196265)
-- Name: dataset_sample_table dataset_sample_table_sample_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.dataset_sample_table
    ADD CONSTRAINT dataset_sample_table_sample_id_fkey FOREIGN KEY (sample_id) REFERENCES public.sample_table(id);


--
-- TOC entry 2363 (class 2606 OID 196270)
-- Name: individual_phenotypic_feature_table individual_phenotypic_feature_table_individual_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: psql_root
--

ALTER TABLE ONLY public.individual_phenotypic_feature_table
    ADD CONSTRAINT individual_phenotypic_feature_table_individual_id_fkey FOREIGN KEY (individual_id) REFERENCES public.individual_table(id);


--
-- TOC entry 2360 (class 2606 OID 196497)
-- Name: ontology_term_table ontology_term_table_ontology_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.ontology_term_table
    ADD CONSTRAINT ontology_term_table_ontology_id_fkey FOREIGN KEY (ontology_id) REFERENCES public.ontology_table(id);


--
-- TOC entry 2359 (class 2606 OID 196275)
-- Name: individual_disease_table patient_disease_table_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.individual_disease_table
    ADD CONSTRAINT patient_disease_table_patient_id_fkey FOREIGN KEY (individual_id) REFERENCES public.individual_table(id);


--
-- TOC entry 2364 (class 2606 OID 196280)
-- Name: sample_table patient_id; Type: FK CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.sample_table
    ADD CONSTRAINT patient_id FOREIGN KEY (individual_id) REFERENCES public.individual_table(id);


--
-- TOC entry 2361 (class 2606 OID 196285)
-- Name: individual_pedigree_table patient_pedigree_table_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.individual_pedigree_table
    ADD CONSTRAINT patient_pedigree_table_patient_id_fkey FOREIGN KEY (individual_id) REFERENCES public.individual_table(id);


--
-- TOC entry 2362 (class 2606 OID 196290)
-- Name: individual_pedigree_table patient_pedigree_table_pedigree_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.individual_pedigree_table
    ADD CONSTRAINT patient_pedigree_table_pedigree_id_fkey FOREIGN KEY (pedigree_id) REFERENCES public.pedigree_table(id);


--
-- TOC entry 2365 (class 2606 OID 196295)
-- Name: tmp_sample_table tmp_sample_table_dataset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.tmp_sample_table
    ADD CONSTRAINT tmp_sample_table_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES public.dataset_table(id);


--
-- TOC entry 2366 (class 2606 OID 196305)
-- Name: tmp_variant_table tmp_variant_table_dataset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.tmp_variant_table
    ADD CONSTRAINT tmp_variant_table_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES public.dataset_table(id);


--
-- TOC entry 2367 (class 2606 OID 196310)
-- Name: variant_table variant_table_dataset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: microaccounts_dev
--

ALTER TABLE ONLY public.variant_table
    ADD CONSTRAINT variant_table_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES public.dataset_table(id);


--
-- TOC entry 2501 (class 0 OID 0)
-- Dependencies: 6
-- Name: SCHEMA addons; Type: ACL; Schema: -; Owner: psql_root
--

GRANT USAGE ON SCHEMA addons TO microaccounts_dev;


--
-- TOC entry 2503 (class 0 OID 0)
-- Dependencies: 245
-- Name: FUNCTION ghstore_in(cstring); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.ghstore_in(cstring) TO microaccounts_dev;


--
-- TOC entry 2504 (class 0 OID 0)
-- Dependencies: 246
-- Name: FUNCTION ghstore_out(addons.ghstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.ghstore_out(addons.ghstore) TO microaccounts_dev;


--
-- TOC entry 2505 (class 0 OID 0)
-- Dependencies: 254
-- Name: FUNCTION hstore_in(cstring); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore_in(cstring) TO microaccounts_dev;


--
-- TOC entry 2506 (class 0 OID 0)
-- Dependencies: 255
-- Name: FUNCTION hstore_out(addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore_out(addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2507 (class 0 OID 0)
-- Dependencies: 256
-- Name: FUNCTION hstore_recv(internal); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore_recv(internal) TO microaccounts_dev;


--
-- TOC entry 2508 (class 0 OID 0)
-- Dependencies: 257
-- Name: FUNCTION hstore_send(addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore_send(addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2509 (class 0 OID 0)
-- Dependencies: 258
-- Name: FUNCTION akeys(addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.akeys(addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2510 (class 0 OID 0)
-- Dependencies: 259
-- Name: FUNCTION avals(addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.avals(addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2511 (class 0 OID 0)
-- Dependencies: 260
-- Name: FUNCTION defined(addons.hstore, text); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.defined(addons.hstore, text) TO microaccounts_dev;


--
-- TOC entry 2512 (class 0 OID 0)
-- Dependencies: 261
-- Name: FUNCTION delete(addons.hstore, addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.delete(addons.hstore, addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2513 (class 0 OID 0)
-- Dependencies: 262
-- Name: FUNCTION delete(addons.hstore, text[]); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.delete(addons.hstore, text[]) TO microaccounts_dev;


--
-- TOC entry 2514 (class 0 OID 0)
-- Dependencies: 263
-- Name: FUNCTION delete(addons.hstore, text); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.delete(addons.hstore, text) TO microaccounts_dev;


--
-- TOC entry 2515 (class 0 OID 0)
-- Dependencies: 264
-- Name: FUNCTION each(hs addons.hstore, OUT key text, OUT value text); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.each(hs addons.hstore, OUT key text, OUT value text) TO microaccounts_dev;


--
-- TOC entry 2516 (class 0 OID 0)
-- Dependencies: 265
-- Name: FUNCTION exist(addons.hstore, text); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.exist(addons.hstore, text) TO microaccounts_dev;


--
-- TOC entry 2517 (class 0 OID 0)
-- Dependencies: 250
-- Name: FUNCTION exists_all(addons.hstore, text[]); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.exists_all(addons.hstore, text[]) TO microaccounts_dev;


--
-- TOC entry 2518 (class 0 OID 0)
-- Dependencies: 251
-- Name: FUNCTION exists_any(addons.hstore, text[]); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.exists_any(addons.hstore, text[]) TO microaccounts_dev;


--
-- TOC entry 2519 (class 0 OID 0)
-- Dependencies: 252
-- Name: FUNCTION fetchval(addons.hstore, text); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.fetchval(addons.hstore, text) TO microaccounts_dev;


--
-- TOC entry 2520 (class 0 OID 0)
-- Dependencies: 266
-- Name: FUNCTION ghstore_compress(internal); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.ghstore_compress(internal) TO microaccounts_dev;


--
-- TOC entry 2521 (class 0 OID 0)
-- Dependencies: 267
-- Name: FUNCTION ghstore_consistent(internal, addons.hstore, smallint, oid, internal); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.ghstore_consistent(internal, addons.hstore, smallint, oid, internal) TO microaccounts_dev;


--
-- TOC entry 2522 (class 0 OID 0)
-- Dependencies: 268
-- Name: FUNCTION ghstore_decompress(internal); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.ghstore_decompress(internal) TO microaccounts_dev;


--
-- TOC entry 2523 (class 0 OID 0)
-- Dependencies: 269
-- Name: FUNCTION ghstore_penalty(internal, internal, internal); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.ghstore_penalty(internal, internal, internal) TO microaccounts_dev;


--
-- TOC entry 2524 (class 0 OID 0)
-- Dependencies: 270
-- Name: FUNCTION ghstore_picksplit(internal, internal); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.ghstore_picksplit(internal, internal) TO microaccounts_dev;


--
-- TOC entry 2525 (class 0 OID 0)
-- Dependencies: 271
-- Name: FUNCTION ghstore_same(addons.ghstore, addons.ghstore, internal); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.ghstore_same(addons.ghstore, addons.ghstore, internal) TO microaccounts_dev;


--
-- TOC entry 2526 (class 0 OID 0)
-- Dependencies: 272
-- Name: FUNCTION ghstore_union(internal, internal); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.ghstore_union(internal, internal) TO microaccounts_dev;


--
-- TOC entry 2527 (class 0 OID 0)
-- Dependencies: 273
-- Name: FUNCTION gin_consistent_hstore(internal, smallint, addons.hstore, integer, internal, internal); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.gin_consistent_hstore(internal, smallint, addons.hstore, integer, internal, internal) TO microaccounts_dev;


--
-- TOC entry 2528 (class 0 OID 0)
-- Dependencies: 274
-- Name: FUNCTION gin_extract_hstore(addons.hstore, internal); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.gin_extract_hstore(addons.hstore, internal) TO microaccounts_dev;


--
-- TOC entry 2529 (class 0 OID 0)
-- Dependencies: 275
-- Name: FUNCTION gin_extract_hstore_query(addons.hstore, internal, smallint, internal, internal); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.gin_extract_hstore_query(addons.hstore, internal, smallint, internal, internal) TO microaccounts_dev;


--
-- TOC entry 2530 (class 0 OID 0)
-- Dependencies: 276
-- Name: FUNCTION hs_concat(addons.hstore, addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hs_concat(addons.hstore, addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2531 (class 0 OID 0)
-- Dependencies: 277
-- Name: FUNCTION hs_contained(addons.hstore, addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hs_contained(addons.hstore, addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2532 (class 0 OID 0)
-- Dependencies: 278
-- Name: FUNCTION hs_contains(addons.hstore, addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hs_contains(addons.hstore, addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2533 (class 0 OID 0)
-- Dependencies: 279
-- Name: FUNCTION hstore(text[]); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore(text[]) TO microaccounts_dev;


--
-- TOC entry 2534 (class 0 OID 0)
-- Dependencies: 280
-- Name: FUNCTION hstore(record); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore(record) TO microaccounts_dev;


--
-- TOC entry 2535 (class 0 OID 0)
-- Dependencies: 281
-- Name: FUNCTION hstore(text[], text[]); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore(text[], text[]) TO microaccounts_dev;


--
-- TOC entry 2536 (class 0 OID 0)
-- Dependencies: 282
-- Name: FUNCTION hstore(text, text); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore(text, text) TO microaccounts_dev;


--
-- TOC entry 2537 (class 0 OID 0)
-- Dependencies: 283
-- Name: FUNCTION hstore_cmp(addons.hstore, addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore_cmp(addons.hstore, addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2538 (class 0 OID 0)
-- Dependencies: 284
-- Name: FUNCTION hstore_eq(addons.hstore, addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore_eq(addons.hstore, addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2539 (class 0 OID 0)
-- Dependencies: 285
-- Name: FUNCTION hstore_ge(addons.hstore, addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore_ge(addons.hstore, addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2540 (class 0 OID 0)
-- Dependencies: 286
-- Name: FUNCTION hstore_gt(addons.hstore, addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore_gt(addons.hstore, addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2541 (class 0 OID 0)
-- Dependencies: 287
-- Name: FUNCTION hstore_hash(addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore_hash(addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2542 (class 0 OID 0)
-- Dependencies: 288
-- Name: FUNCTION hstore_le(addons.hstore, addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore_le(addons.hstore, addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2543 (class 0 OID 0)
-- Dependencies: 289
-- Name: FUNCTION hstore_lt(addons.hstore, addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore_lt(addons.hstore, addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2544 (class 0 OID 0)
-- Dependencies: 290
-- Name: FUNCTION hstore_ne(addons.hstore, addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore_ne(addons.hstore, addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2545 (class 0 OID 0)
-- Dependencies: 291
-- Name: FUNCTION hstore_to_array(addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore_to_array(addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2546 (class 0 OID 0)
-- Dependencies: 292
-- Name: FUNCTION hstore_to_json(addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore_to_json(addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2547 (class 0 OID 0)
-- Dependencies: 293
-- Name: FUNCTION hstore_to_json_loose(addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore_to_json_loose(addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2548 (class 0 OID 0)
-- Dependencies: 294
-- Name: FUNCTION hstore_to_jsonb(addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore_to_jsonb(addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2549 (class 0 OID 0)
-- Dependencies: 295
-- Name: FUNCTION hstore_to_jsonb_loose(addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore_to_jsonb_loose(addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2550 (class 0 OID 0)
-- Dependencies: 296
-- Name: FUNCTION hstore_to_matrix(addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore_to_matrix(addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2551 (class 0 OID 0)
-- Dependencies: 297
-- Name: FUNCTION hstore_version_diag(addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.hstore_version_diag(addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2552 (class 0 OID 0)
-- Dependencies: 298
-- Name: FUNCTION isdefined(addons.hstore, text); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.isdefined(addons.hstore, text) TO microaccounts_dev;


--
-- TOC entry 2553 (class 0 OID 0)
-- Dependencies: 299
-- Name: FUNCTION isexists(addons.hstore, text); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.isexists(addons.hstore, text) TO microaccounts_dev;


--
-- TOC entry 2554 (class 0 OID 0)
-- Dependencies: 300
-- Name: FUNCTION populate_record(anyelement, addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.populate_record(anyelement, addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2555 (class 0 OID 0)
-- Dependencies: 301
-- Name: FUNCTION skeys(addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.skeys(addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2556 (class 0 OID 0)
-- Dependencies: 302
-- Name: FUNCTION slice(addons.hstore, text[]); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.slice(addons.hstore, text[]) TO microaccounts_dev;


--
-- TOC entry 2557 (class 0 OID 0)
-- Dependencies: 303
-- Name: FUNCTION slice_array(addons.hstore, text[]); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.slice_array(addons.hstore, text[]) TO microaccounts_dev;


--
-- TOC entry 2558 (class 0 OID 0)
-- Dependencies: 304
-- Name: FUNCTION svals(addons.hstore); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.svals(addons.hstore) TO microaccounts_dev;


--
-- TOC entry 2559 (class 0 OID 0)
-- Dependencies: 305
-- Name: FUNCTION tconvert(text, text); Type: ACL; Schema: addons; Owner: psql_root
--

GRANT ALL ON FUNCTION addons.tconvert(text, text) TO microaccounts_dev;


--
-- TOC entry 2564 (class 0 OID 0)
-- Dependencies: 207
-- Name: TABLE individual_phenotypic_feature_table; Type: ACL; Schema: public; Owner: psql_root
--

GRANT ALL ON TABLE public.individual_phenotypic_feature_table TO microaccounts_dev;


--
-- TOC entry 2566 (class 0 OID 0)
-- Dependencies: 208
-- Name: SEQUENCE individual_phenotypic_feature_table_id_seq; Type: ACL; Schema: public; Owner: psql_root
--

GRANT ALL ON SEQUENCE public.individual_phenotypic_feature_table_id_seq TO microaccounts_dev;


-- Completed on 2020-09-03 18:43:25 CEST

--
-- PostgreSQL database dump complete
--


-- Grant permissions

GRANT ALL PRIVILEGES ON DATABASE elixir_beacon_v2_giab_dev TO microaccounts_dev; 
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO microaccounts_dev;  
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO microaccounts_dev;  
